// Dev helper: renders still frames of Main to out/stills (bundles once).
// Usage: node scripts/stills.mjs 10 60 120 ...   (BROWSER=/path/to/chrome to override)
import path from "node:path";
import fs from "node:fs";
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";

const frames = process.argv.slice(2).map(Number);
const browserExecutable = process.env.BROWSER || undefined;
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts"), publicDir: path.resolve("public") });
const comp = await selectComposition({ serveUrl, id: "Main", browserExecutable });
fs.mkdirSync("out/stills", { recursive: true });
for (const f of frames) {
  await renderStill({ composition: comp, serveUrl, frame: f, output: `out/stills/f_${String(f).padStart(4, "0")}.png`, browserExecutable, overwrite: true });
  console.log("frame", f, "ok");
}
console.log("total frames", comp.durationInFrames);
