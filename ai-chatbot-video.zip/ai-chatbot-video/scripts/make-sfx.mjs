// Synthesizes a small, soft, professional UI-sound kit into public/sfx/*.wav
// Run: node scripts/make-sfx.mjs
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = path.resolve("public/sfx");
fs.mkdirSync(OUT, { recursive: true });

const TARGET_PEAK = 0.8; // every sound is normalised to the same peak -> equal level
let seed = 1234567;
const rnd = () => {
  // deterministic noise
  seed = (seed * 1664525 + 1013904223) >>> 0;
  return (seed / 4294967296) * 2 - 1;
};
const buf = (sec) => new Float32Array(Math.floor(sec * SR));

// ---- filters ----
function lowpass(x, fc) {
  const a = Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  const out = new Float32Array(x.length);
  for (let i = 0; i < x.length; i++) {
    y = (1 - a) * x[i] + a * y;
    out[i] = y;
  }
  return out;
}
function highpass(x, fc) {
  const lp = lowpass(x, fc);
  return x.map((v, i) => v - lp[i]);
}
// state-variable band-pass with per-sample centre frequency
function bandpassSweep(x, fcAt, q) {
  const out = new Float32Array(x.length);
  let low = 0,
    band = 0;
  for (let i = 0; i < x.length; i++) {
    const f = 2 * Math.sin((Math.PI * fcAt(i / x.length)) / SR);
    low += f * band;
    const high = x[i] - low - band / q;
    band += f * high;
    out[i] = band;
  }
  return out;
}
// tiny Schroeder-style reverb (short, subtle)
function reverb(x, mix = 0.12) {
  const delays = [0.0297, 0.0371, 0.0411, 0.0437].map((d) => Math.floor(d * SR));
  const tail = Math.floor(0.12 * SR);
  const out = new Float32Array(x.length + tail);
  out.set(x);
  const wet = new Float32Array(out.length);
  for (const d of delays) {
    for (let i = 0; i < x.length; i++) {
      let g = 0.5;
      for (let k = 1; k < 4; k++) {
        const j = i + d * k;
        if (j < wet.length) wet[j] += x[i] * g * 0.25;
        g *= 0.45;
      }
    }
  }
  const wl = lowpass(wet, 3500);
  for (let i = 0; i < out.length; i++) out[i] += wl[i] * mix * 4;
  return out;
}
const env = (t, attack, decay) => Math.min(1, t / attack) * Math.exp(-t / decay);

function finish(x, { lp = 7500, rv = 0.12, fadeMs = 25 } = {}) {
  let y = lowpass(x, lp);
  y = reverb(y, rv);
  const fade = Math.floor((fadeMs / 1000) * SR);
  for (let i = 0; i < fade; i++) y[y.length - 1 - i] *= i / fade;
  let peak = 0;
  for (const v of y) peak = Math.max(peak, Math.abs(v));
  const g = TARGET_PEAK / (peak || 1);
  return y.map((v) => v * g);
}

// ---- sounds ----
function pop() {
  const x = buf(0.2);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 180 + 420 * Math.exp(-t / 0.028); // fast downward pitch
    ph += (2 * Math.PI * f) / SR;
    x[i] = (Math.sin(ph) + 0.25 * Math.sin(2 * ph)) * env(t, 0.004, 0.05);
  }
  return finish(x, { lp: 6000, rv: 0.1 });
}
function click() {
  const x = buf(0.09);
  const n = buf(0.09);
  for (let i = 0; i < n.length; i++) n[i] = rnd();
  const hp = highpass(n, 2200);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] = hp[i] * env(t, 0.0008, 0.011) + 0.5 * Math.sin(2 * Math.PI * 1700 * t) * env(t, 0.0005, 0.008);
  }
  return finish(x, { lp: 8000, rv: 0.06, fadeMs: 15 });
}
function whooshOf(sec, f0, f1, peakAt) {
  const n = buf(sec);
  for (let i = 0; i < n.length; i++) n[i] = rnd();
  const bp = bandpassSweep(n, (p) => f0 * Math.pow(f1 / f0, p), 1.6);
  for (let i = 0; i < bp.length; i++) {
    const p = i / bp.length;
    const e = p < peakAt ? Math.sin((p / peakAt) * (Math.PI / 2)) ** 2 : Math.cos(((p - peakAt) / (1 - peakAt)) * (Math.PI / 2)) ** 2;
    bp[i] *= e;
  }
  return bp;
}
const whoosh = () => finish(whooshOf(0.62, 350, 2800, 0.38), { lp: 6500, rv: 0.1 });
const swipe = () => finish(whooshOf(0.38, 700, 4200, 0.45), { lp: 7000, rv: 0.08 });
function chime() {
  const x = buf(0.45);
  const partials = [
    [880, 1, 0.16],
    [1318.5, 0.55, 0.12],
    [1760, 0.3, 0.09],
    [2637, 0.12, 0.05],
  ];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let s = 0;
    for (const [f, a, d] of partials) s += a * Math.sin(2 * Math.PI * f * t + 0.3) * env(t, 0.008, d);
    x[i] = s;
  }
  return finish(x, { lp: 6500, rv: 0.16 });
}
function thud() {
  const x = buf(0.32);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const f = 52 + 60 * Math.exp(-t / 0.06);
    ph += (2 * Math.PI * f) / SR;
    x[i] = Math.sin(ph) * env(t, 0.006, 0.09);
  }
  return finish(x, { lp: 700, rv: 0.05 });
}

const kit = { pop, click, whoosh, swipe, chime, thud };

function writeWav(file, f32) {
  const data = Buffer.alloc(f32.length * 2);
  for (let i = 0; i < f32.length; i++) {
    const v = Math.max(-1, Math.min(1, f32[i]));
    data.writeInt16LE(Math.round(v * 32767), i * 2);
  }
  const h = Buffer.alloc(44);
  h.write("RIFF", 0);
  h.writeUInt32LE(36 + data.length, 4);
  h.write("WAVEfmt ", 8);
  h.writeUInt32LE(16, 16);
  h.writeUInt16LE(1, 20);
  h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28);
  h.writeUInt16LE(2, 32);
  h.writeUInt16LE(16, 34);
  h.write("data", 36);
  h.writeUInt32LE(data.length, 40);
  fs.writeFileSync(file, Buffer.concat([h, data]));
}

const report = {};
for (const [name, fn] of Object.entries(kit)) {
  const x = fn();
  writeWav(path.join(OUT, `${name}.wav`), x);
  let peak = 0,
    clip = 0,
    sum = 0;
  for (const v of x) {
    peak = Math.max(peak, Math.abs(v));
    if (Math.abs(v) >= 0.999) clip++;
    sum += v * v;
  }
  report[name] = {
    seconds: +(x.length / SR).toFixed(3),
    peak: +peak.toFixed(3),
    rms: +Math.sqrt(sum / x.length).toFixed(3),
    clippedSamples: clip,
  };
}
console.table(report);
fs.writeFileSync(path.join(OUT, "manifest.json"), JSON.stringify(report, null, 2));
