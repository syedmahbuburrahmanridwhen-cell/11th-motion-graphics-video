# AI Chatbot Video (Remotion) — 1920×1080, 30fps, ~66.9s, Obsidian Blue (dark)

    npm install
    npx remotion studio                                  # preview (composition id: Main)
    npx remotion render src/index.ts Main out/video.mp4  # render MP4 (SFX included)

- Timing: everything derives from `src/script.srt.ts` (the SRT). Scenes are cue ranges in `src/timeline.ts`.
- Colours/fonts/easing/springs: `src/theme.ts` only. Fonts bundled offline in `public/fonts`.
- Optional voice-over preview: put `public/voiceover.mp3` (plays in Studio; off in render — flags in `src/config.ts`).
- SFX: `public/sfx/*.wav` (regenerate with `npm run sfx`).
