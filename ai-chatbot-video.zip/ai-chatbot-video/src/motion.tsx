import React, { createContext, useContext } from "react";
import { Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import type { SpringConfig } from "remotion";
import { theme } from "./theme";
import { localFrame, type SceneTiming } from "./timeline";

export const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/* ---------- scene context: SRT-derived local timing ---------- */
const SceneCtx = createContext<SceneTiming | null>(null);
export const SceneProvider = SceneCtx.Provider;
export const useScene = () => {
  const scene = useContext(SceneCtx);
  if (!scene) throw new Error("useScene outside <SceneProvider>");
  return { scene, at: (n: number, frac = 0) => localFrame(scene, n, frac) };
};

/* ---------- spring helper ---------- */
export const useSpringAt = (delay: number, cfg: Partial<SpringConfig> = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: cfg });
};

/** Idle breathing: scale + float so nothing on screen is ever frozen. */
export const useBreath = (amp = 0.015, speed = 22, phase = 0) => {
  const frame = useCurrentFrame() + phase;
  return {
    s: 1 + Math.sin(frame / speed) * amp,
    y: Math.sin(frame / (speed * 1.35)) * 4,
    r: Math.sin(frame / (speed * 1.8)) * 1.2,
  };
};

/* ---------- Pop: opacity + translate + scale (+blur) entrance, faster exit ---------- */
export const Pop: React.FC<{
  delay?: number;
  x?: number;
  y?: number;
  from?: number;
  blur?: number;
  cfg?: Partial<SpringConfig>;
  exitAt?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({ delay = 0, x = 0, y = 40, from = 0.92, blur = 0, cfg = theme.spring.smooth, exitAt, style, children }) => {
  const frame = useCurrentFrame();
  const p = useSpringAt(delay, cfg);
  const ex =
    exitAt === undefined
      ? 0
      : interpolate(frame, [exitAt, exitAt + 9], [0, 1], { easing: theme.ease.in, ...clamp });
  const opacity = Math.min(1, p * 1.6) * (1 - ex);
  const ty = interpolate(p, [0, 1], [y, 0]) - ex * 26;
  const tx = interpolate(p, [0, 1], [x, 0]);
  const sc = interpolate(p, [0, 1], [from, 1]) * (1 - ex * 0.05);
  const b = (1 - Math.min(1, p)) * blur + ex * 6;
  return (
    <div
      style={{
        opacity,
        transform: `translate(${tx}px, ${ty}px) scale(${sc})`,
        filter: b > 0.05 ? `blur(${b}px)` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/* ---------- inline mark-up: *hero* , _accent_ , ~gradient~ (word level, split on spaces only) ---------- */
type Kind = "plain" | "hero" | "accent" | "grad";
export const parseMarks = (text: string): { t: string; kind: Kind }[] => {
  let kind: Kind = "plain";
  const out: { t: string; kind: Kind }[] = [];
  for (const raw of text.split(" ")) {
    let w = raw;
    let closeAfter = false;
    const open = (m: string, k: Kind) => {
      if (w.startsWith(m)) {
        kind = k;
        w = w.slice(1);
      }
    };
    open("*", "hero");
    open("_", "accent");
    open("~", "grad");
    for (const m of ["*", "_", "~"]) {
      if (w.endsWith(m)) {
        w = w.slice(0, -1);
        closeAfter = true;
      }
    }
    out.push({ t: w, kind });
    if (closeAfter) kind = "plain";
  }
  return out;
};

export const wordStyle = (kind: Kind, glow = false): React.CSSProperties => {
  if (kind === "hero")
    return { color: theme.colors.primary, textShadow: glow ? `0 0 44px ${theme.colors.glow}` : undefined };
  if (kind === "accent") return { color: theme.colors.accent };
  if (kind === "grad")
    return {
      backgroundImage: `linear-gradient(100deg, ${theme.colors.primary}, ${theme.colors.accent})`,
      WebkitBackgroundClip: "text",
      backgroundClip: "text",
      color: "transparent",
      WebkitTextFillColor: "transparent",
    };
  return {};
};

/* ---------- WordReveal: staggered word-by-word (never splits inside a Bengali word) ---------- */
export const WordReveal: React.FC<{
  text: string;
  delay?: number;
  per?: number;
  size: number;
  weight?: number;
  color?: string;
  gap?: number;
  align?: "flex-start" | "center" | "flex-end";
  glow?: boolean;
  exitAt?: number;
  style?: React.CSSProperties;
}> = ({ text, delay = 0, per = 4, size, weight = theme.fonts.weight.heavy, color = theme.colors.text, gap, align = "flex-start", glow, exitAt, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = parseMarks(text);
  const ex = exitAt === undefined ? 0 : interpolate(frame, [exitAt, exitAt + 9], [0, 1], { easing: theme.ease.in, ...clamp });
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        columnGap: gap ?? Math.round(size * 0.26),
        fontFamily: theme.fonts.display,
        fontSize: size,
        fontWeight: weight,
        lineHeight: theme.lh.hero,
        letterSpacing: 0,
        color,
        opacity: 1 - ex,
        transform: `translateY(${-ex * 24}px)`,
        ...style,
      }}
    >
      {words.map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              opacity: Math.min(1, p * 1.6),
              transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.9, 1])})`,
              filter: p < 0.98 ? `blur(${(1 - p) * 8}px)` : undefined,
              ...wordStyle(w.kind, glow),
            }}
          >
            {w.t}
          </span>
        );
      })}
    </div>
  );
};

/* ---------- MaskLine: line mask reveal (padding keeps Bengali matras from clipping) ---------- */
export const MaskLine: React.FC<{ delay?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ delay = 0, children, style }) => {
  const p = useSpringAt(delay, theme.spring.smooth);
  return (
    <div style={{ overflow: "hidden", padding: "0.2em 0.12em 0.34em", margin: "-0.2em -0.12em -0.34em", ...style }}>
      <div style={{ transform: `translateY(${(1 - p) * 115}%)`, opacity: Math.min(1, p * 3) }}>{children}</div>
    </div>
  );
};

/* ---------- SFX ---------- */
export type SfxName = "pop" | "click" | "whoosh" | "swipe" | "chime" | "thud";
// len = seconds (matches public/sfx/manifest.json), vol = moderated gain so VO is never covered
const SFX: Record<SfxName, { len: number; vol: number }> = {
  pop: { len: 0.34, vol: 0.3 },
  click: { len: 0.22, vol: 0.34 },
  whoosh: { len: 0.76, vol: 0.26 },
  swipe: { len: 0.52, vol: 0.26 },
  chime: { len: 0.6, vol: 0.3 },
  thud: { len: 0.46, vol: 0.22 },
};
/** Plays a synthesized SFX at frame `at` (relative to the enclosing Sequence). `v` varies pitch/volume slightly. */
export const Sfx: React.FC<{ name: SfxName; at: number; v?: number }> = ({ name, at, v = 0 }) => {
  const { fps } = useVideoConfig();
  const rate = 1 + (((v * 37) % 7) - 3) * 0.02;
  const vol = SFX[name].vol * (1 - ((v * 13) % 5) * 0.035);
  return (
    <Sequence from={Math.max(0, Math.round(at))} durationInFrames={Math.ceil((SFX[name].len * fps) / rate) + 2} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} playbackRate={rate} />
    </Sequence>
  );
};
