// Offline fonts: woff2 files live in public/fonts (copied from @fontsource/hind-siliguri).
import { continueRender, delayRender, staticFile } from "remotion";

const BN_RANGE =
  "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CD0,U+1CD2,U+1CD5-1CD6,U+1CD8,U+1CE1,U+1CEA,U+1CED,U+1CF2,U+1CF5-1CF7,U+200C-200D,U+20B9,U+25CC,U+A8F1";

const faces: { weight: number; subset: "latin" | "bengali"; range?: string }[] = [
  { weight: 500, subset: "latin" },
  { weight: 700, subset: "latin" },
  { weight: 500, subset: "bengali", range: BN_RANGE },
  { weight: 700, subset: "bengali", range: BN_RANGE },
];

let started = false;
export const loadFonts = () => {
  if (started || typeof document === "undefined") return;
  started = true;
  const handle = delayRender("fonts");
  const jobs = faces.map(async (f) => {
    const face = new FontFace(
      "Hind Siliguri",
      `url(${staticFile(`fonts/hind-siliguri-${f.subset}-${f.weight}-normal.woff2`)}) format("woff2")`,
      { weight: String(f.weight), style: "normal", ...(f.range ? { unicodeRange: f.range } : {}) }
    );
    await face.load();
    document.fonts.add(face);
  });
  Promise.all(jobs)
    .then(() => document.fonts.ready)
    .then(() => continueRender(handle))
    .catch((e) => {
      console.error("Font load failed", e);
      continueRender(handle);
    });
};
