// Timeline: parses the SRT and derives EVERY timing in the video from it.
import { SRT } from "./script.srt";
import { FPS, LEAD_FRAMES } from "./config";

export type Cue = { n: number; start: number; end: number; text: string };

const ts = (s: string) => {
  const [h, m, rest] = s.trim().split(":");
  const [sec, ms] = rest.split(",");
  return +h * 3600 + +m * 60 + +sec + +ms / 1000;
};

export const cues: Cue[] = SRT.trim()
  .split(/\n\s*\n/)
  .map((block) => {
    const lines = block.trim().split("\n");
    const [a, b] = lines[1].split("-->");
    return { n: +lines[0], start: ts(a), end: ts(b), text: lines.slice(2).join(" ") };
  });

const byN = (n: number) => {
  const c = cues.find((x) => x.n === n);
  if (!c) throw new Error(`cue ${n} not in SRT`);
  return c;
};

/** Absolute frame of a point inside cue n (frac 0 = cue start, 1 = cue end). */
export const cueFrame = (n: number, frac = 0) => {
  const c = byN(n);
  return Math.round((c.start + (c.end - c.start) * frac) * FPS);
};

/** Total length = end of the last cue (SRT wins over any audio length). */
export const TOTAL_FRAMES = Math.ceil(cues[cues.length - 1].end * FPS);

/** Scene = semantic block of whole cues. Boundaries always sit on cue starts. */
export type SceneDef = { id: string; firstCue: number; lastCue: number };

export const sceneDefs: SceneDef[] = [
  { id: "hook", firstCue: 1, lastCue: 2 },
  { id: "broken", firstCue: 3, lastCue: 4 },
  { id: "relax", firstCue: 5, lastCue: 6 },
  { id: "chat", firstCue: 7, lastCue: 10 },
  { id: "data", firstCue: 11, lastCue: 13 },
  { id: "studio", firstCue: 14, lastCue: 17 },
  { id: "guide", firstCue: 18, lastCue: 21 },
  { id: "send", firstCue: 22, lastCue: 23 },
  { id: "test", firstCue: 24, lastCue: 25 },
  { id: "cta", firstCue: 26, lastCue: 30 },
];

export type SceneTiming = SceneDef & { index: number; from: number; to: number; duration: number };

export const scenes: SceneTiming[] = sceneDefs.map((d, i) => {
  const from = i === 0 ? 0 : cueFrame(d.firstCue) - LEAD_FRAMES;
  const next = sceneDefs[i + 1];
  const to = next ? cueFrame(next.firstCue) - LEAD_FRAMES : TOTAL_FRAMES;
  return { ...d, index: i, from, to, duration: to - from };
});

/** Scene-local frame of a point inside cue n, already shifted LEAD_FRAMES earlier. */
export const localFrame = (scene: SceneTiming, n: number, frac = 0) =>
  cueFrame(n, frac) - LEAD_FRAMES - scene.from;
