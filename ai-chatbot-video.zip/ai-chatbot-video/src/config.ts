// Project-wide constants. Change FPS here (e.g. 60) and every SRT-derived time follows.
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** Visuals enter this many frames BEFORE the related narration (4-6 per brief). */
export const LEAD_FRAMES = 5;

/** Voice-over preview flags (public/voiceover.mp3 is optional). */
export const VOICEOVER_IN_STUDIO = true; // plays in Remotion Studio preview when the file exists
export const VOICEOVER_IN_RENDER = false; // keep false: the final render carries SFX only
export const VOICEOVER_FILE = "voiceover.mp3";
