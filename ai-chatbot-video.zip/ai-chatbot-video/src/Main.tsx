import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { theme } from "./theme";
import { scenes } from "./timeline";
import { SceneProvider, Sfx } from "./motion";
import { BgMesh, Grade, Grain, Transitions, Vignette } from "./layers";
import { ProcessRail } from "./ui";
import { PreviewAudio } from "./PreviewAudio";
import { Hook } from "./scenes/Hook";
import { Broken } from "./scenes/Broken";
import { Relax } from "./scenes/Relax";
import { Chat } from "./scenes/Chat";
import { Data } from "./scenes/Data";
import { Studio } from "./scenes/Studio";
import { Guide } from "./scenes/Guide";
import { Send } from "./scenes/Send";
import { Test } from "./scenes/Test";
import { Cta } from "./scenes/Cta";

const registry: Record<string, React.FC> = {
  hook: Hook,
  broken: Broken,
  relax: Relax,
  chat: Chat,
  data: Data,
  studio: Studio,
  guide: Guide,
  send: Send,
  test: Test,
  cta: Cta,
};

const Placeholder: React.FC = () => null;

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg, fontFamily: theme.fonts.body }}>
    {/* layer 1 */}
    <BgMesh />
    {/* layers 2-3: assets + graphics/type, one Sequence per SRT-derived scene */}
    {scenes.map((s) => {
      const Scene = registry[s.id] ?? Placeholder;
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.duration} name={s.id}>
          <SceneProvider value={s}>
            <Scene />
          </SceneProvider>
        </Sequence>
      );
    })}
    <ProcessRail />
    <Transitions />
    {scenes.slice(1).map((s, i) => (
      <Sfx key={s.id} name="swipe" at={s.from - 9} v={i} />
    ))}
    {/* layer 4: grade · layer 5: grain + vignette */}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);
