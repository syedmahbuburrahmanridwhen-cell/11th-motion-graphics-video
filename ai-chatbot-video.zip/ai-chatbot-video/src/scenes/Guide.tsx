import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, clamp, useBreath, useScene, useSpringAt } from "../motion";
import { AiOrb, GlassCard, Pill, SceneShell } from "../ui";
import { BulbIcon, DocIcon, LockIcon } from "../icons";

// Scene 7 — Hub-and-spoke: guidelines + secret instructions → AI tool → smart answers. Cues 18-21.
const HubCard: React.FC<{ delay: number; left: number; top: number; icon: React.ReactNode; title: string; hero?: boolean }> = ({ delay, left, top, icon, title, hero }) => {
  const b = useBreath(0.01, 26, left);
  return (
    <Pop delay={delay} y={50} x={left < 900 ? -60 : 60} from={0.88} cfg={theme.spring.smooth} style={{ position: "absolute", left, top }}>
      <div style={{ transform: `translateY(${b.y}px) scale(${b.s})` }}>
        <GlassCard style={{ width: 520, height: 170, display: "flex", alignItems: "center", gap: 28, padding: "0 34px", border: `1px solid ${hero ? theme.colors.primaryLine : theme.colors.line}`, boxShadow: hero ? `0 0 60px ${theme.colors.glowSoft}, ${theme.shadow.card}` : theme.shadow.card }}>
          <div style={{ width: 96, height: 96, borderRadius: 28, background: hero ? theme.colors.primary : theme.colors.primaryTint, border: `1px solid ${theme.colors.primaryLine}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{icon}</div>
          <div style={{ fontFamily: theme.fonts.display, fontSize: 46, fontWeight: theme.fonts.weight.heavy, color: theme.colors.text, lineHeight: theme.lh.body, letterSpacing: 0 }}>{title}</div>
        </GlassCard>
      </div>
    </Pop>
  );
};

type Pts = [number, number, number, number, number, number, number, number];
const bez = (P: Pts, t: number) => {
  const u = 1 - t;
  const x = u * u * u * P[0] + 3 * u * u * t * P[2] + 3 * u * t * t * P[4] + t * t * t * P[6];
  const y = u * u * u * P[1] + 3 * u * u * t * P[3] + 3 * u * t * t * P[5] + t * t * t * P[7];
  return { x, y };
};
const Link: React.FC<{ P: Pts; delay: number; dotColor?: string; speed?: number }> = ({ P, delay, dotColor = theme.colors.primary, speed = 0.012 }) => {
  const frame = useCurrentFrame();
  const p = useSpringAt(delay, theme.spring.smooth);
  const d = `M${P[0]} ${P[1]} C ${P[2]} ${P[3]}, ${P[4]} ${P[5]}, ${P[6]} ${P[7]}`;
  return (
    <g opacity={Math.min(1, p * 1.5)}>
      <path d={d} fill="none" stroke={theme.colors.primaryLine} strokeWidth={3} strokeDasharray="4 14" strokeLinecap="round" strokeDashoffset={-frame * 1.4} />
      {[0, 1, 2].map((k) => {
        const t = (frame * speed + k / 3) % 1;
        const q = bez(P, t);
        return <circle key={k} cx={q.x} cy={q.y} r={9} fill={k === 0 ? theme.colors.accent : dotColor} opacity={interpolate(t, [0, 0.1, 0.9, 1], [0, 1, 1, 0], clamp) * Math.min(1, p * 1.5)} />;
      })}
    </g>
  );
};

export const Guide: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const orbAt = 2;
  const aAt = at(18, 0.5);
  const bAt = at(19, 0.0);
  const lockAt = at(19, 0.3);
  const tagAt = at(20, 0.28);
  const cAt = at(20, 0.55);
  const energy = at(21, 0.1);
  const lockOpen = interpolate(frame, [lockAt, lockAt + 10], [1, 0], { easing: theme.ease.out, ...clamp });
  return (
    <SceneShell>
      <AbsoluteFill>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <Link P={[630, 335, 720, 335, 720, 440, 806, 446]} delay={aAt + 8} />
          <Link P={[630, 615, 720, 615, 720, 500, 806, 494]} delay={bAt + 8} speed={0.014} />
          <Link P={[1114, 470, 1190, 470, 1210, 470, 1290, 470]} delay={cAt - 6} dotColor={theme.colors.accent} speed={0.016} />
        </svg>
        {/* energy rings when the tool gets its ability */}
        {[0, 1, 2].map((k) => {
          const t = interpolate(frame, [energy + k * 7, energy + 30 + k * 7], [0, 1], { easing: theme.ease.out, ...clamp });
          return <div key={k} style={{ position: "absolute", left: 960 - 190, top: 470 - 190, width: 380, height: 380, borderRadius: "50%", border: `3px solid ${k === 1 ? theme.colors.accent : theme.colors.primary}`, opacity: frame < energy ? 0 : (1 - t) * 0.7, transform: `scale(${0.8 + t * 1.8})` }} />;
        })}
        <div style={{ position: "absolute", left: 750, top: 260 }}>
          <AiOrb size={420} delay={orbAt} pulseAt={energy} />
        </div>
        <HubCard delay={aAt} left={110} top={250} icon={<DocIcon size={54} color={theme.colors.primary} sw={1.8} />} title="guidelines" />
        <HubCard delay={bAt} left={110} top={530} icon={<LockIcon size={54} color={theme.colors.primary} sw={1.8} open={lockOpen} />} title="secret নির্দেশনা" />
        <Pop delay={tagAt} y={20} style={{ position: "absolute", left: 1290, top: 300 }}>
          <Pill size={32}>মানুষের মতো</Pill>
        </Pop>
        <HubCard delay={cAt} left={1290} top={385} hero icon={<BulbIcon size={54} color={theme.colors.bg} sw={2} />} title="বুদ্ধিদীপ্ত জবাব" />
        <Sfx name="pop" at={orbAt} v={2} />
        <Sfx name="pop" at={aAt} v={6} />
        <Sfx name="pop" at={bAt} v={1} />
        <Sfx name="click" at={lockAt + 8} v={4} />
        <Sfx name="chime" at={cAt} v={4} />
        <Sfx name="whoosh" at={energy - 2} v={5} />
      </AbsoluteFill>
    </SceneShell>
  );
};
