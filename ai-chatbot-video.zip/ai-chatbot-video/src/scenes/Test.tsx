import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, clamp, useBreath, useScene, useSpringAt } from "../motion";
import { AiOrb, GlassCard, SceneShell } from "../ui";
import { CheckIcon, QuestionIcon } from "../icons";

// Scene 9 — Process step "Test": READY burst → question → AI → works. Cues 24-25.
const Flow: React.FC<{ x0: number; x1: number; y: number; delay: number }> = ({ x0, x1, y, delay }) => {
  const frame = useCurrentFrame();
  const p = useSpringAt(delay, theme.spring.smooth);
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, opacity: Math.min(1, p * 1.5) }}>
      <line x1={x0} y1={y} x2={x0 + (x1 - x0) * p} y2={y} stroke={theme.colors.primaryLine} strokeWidth={3} strokeDasharray="4 14" strokeLinecap="round" strokeDashoffset={-frame * 1.6} />
      {[0, 1].map((k) => {
        const t = ((frame * 0.016 + k / 2) % 1) * p;
        return <circle key={k} cx={x0 + (x1 - x0) * t} cy={y} r={9} fill={k ? theme.colors.primary : theme.colors.accent} opacity={interpolate(t, [0, 0.12, 0.88, 1], [0, 1, 1, 0], clamp)} />;
      })}
    </svg>
  );
};

export const Test: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { at } = useScene();
  const b = useBreath(0.012, 26);
  const qAt = at(24, 0.55);
  const orbAt = at(24, 0.3);
  const procAt = at(25, 0.0);
  const resAt = at(25, 0.45);
  const tick = useSpringAt(resAt + 6, theme.spring.bouncy);
  return (
    <SceneShell>
      <AbsoluteFill>
        {/* READY burst */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 80, display: "flex", justifyContent: "center", alignItems: "center", gap: 40 }}>
          <Pop delay={0} y={0} from={0.3} cfg={theme.spring.bouncy} style={{ position: "relative", width: 130, height: 130 }}>
            {Array.from({ length: 14 }).map((_, i) => {
              const p = spring({ frame: frame - 6 - i * 0.7, fps, config: theme.spring.snappy });
              const fade = interpolate(frame, [10, 40], [1, 0], clamp);
              return <div key={i} style={{ position: "absolute", left: 62, top: 62, width: 6, height: 30, borderRadius: 6, background: i % 2 ? theme.colors.accent : theme.colors.primary, opacity: fade * Math.min(1, p), transformOrigin: "3px 3px", transform: `rotate(${(360 / 14) * i}deg) translateY(${86 + p * 40}px)` }} />;
            })}
            <div style={{ position: "absolute", inset: 0, borderRadius: "50%", background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 60px ${theme.colors.accentGlow}`, transform: `scale(${b.s})` }}>
              <CheckIcon size={78} color={theme.colors.bg} sw={3.2} />
            </div>
          </Pop>
          <WordReveal text="একদম *ready*" delay={3} per={6} size={156} glow />
        </div>

        {/* question → AI → result */}
        <Pop delay={qAt} y={40} x={-60} style={{ position: "absolute", left: 120, top: 440 }}>
          <GlassCard style={{ width: 400, height: 170, display: "flex", alignItems: "center", gap: 24, padding: "0 36px" }}>
            <QuestionIcon size={70} color={theme.colors.primary} sw={1.6} />
            <div style={{ fontFamily: theme.fonts.display, fontSize: 50, fontWeight: theme.fonts.weight.heavy, color: theme.colors.text, lineHeight: theme.lh.body, letterSpacing: 0 }}>question</div>
          </GlassCard>
        </Pop>
        <Flow x0={540} x1={800} y={525} delay={qAt + 10} />
        <div style={{ position: "absolute", left: 960 - 160, top: 525 - 160 }}>
          <AiOrb size={320} delay={orbAt} pulseAt={procAt} />
        </div>
        <Flow x0={1120} x1={1290} y={525} delay={procAt + 4} />
        <Pop delay={resAt} y={40} x={60} from={0.9} style={{ position: "absolute", left: 1290, top: 440 }}>
          <GlassCard style={{ width: 540, height: 170, display: "flex", alignItems: "center", gap: 26, padding: "0 34px", border: `1px solid ${theme.colors.accentLine}`, boxShadow: `0 0 70px ${theme.colors.accentGlow}, ${theme.shadow.card}` }}>
            <div style={{ width: 72, height: 72, borderRadius: "50%", background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${0.5 + 0.5 * Math.min(1.1, tick)})`, flexShrink: 0 }}>
              <CheckIcon size={44} color={theme.colors.bg} sw={3.4} />
            </div>
            <div style={{ fontFamily: theme.fonts.display, fontSize: 40, fontWeight: theme.fonts.weight.heavy, color: theme.colors.text, lineHeight: theme.lh.body, letterSpacing: 0 }}>ঠিকমতো কাজ করছে</div>
          </GlassCard>
        </Pop>
        <Sfx name="chime" at={2} v={5} />
        <Sfx name="thud" at={4} v={3} />
        <Sfx name="pop" at={qAt} v={4} />
        <Sfx name="pop" at={orbAt} v={6} />
        <Sfx name="pop" at={resAt} v={1} />
        <Sfx name="click" at={resAt + 8} v={4} />
      </AbsoluteFill>
    </SceneShell>
  );
};
