import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, clamp, useBreath, useScene, useSpringAt } from "../motion";
import { AiOrb, Cursor, GlassCard, Pill, SceneShell, Skel } from "../ui";
import { CommentIcon, DocIcon, MailIcon, SendIcon, SparkIcon } from "../icons";

// Scene 10 — CTA: comment "বাংলাদেশি AI" → inbox. Cues 26-30.
export const Cta: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const b = useBreath(0.01, 28);
  const l1 = at(26, 0.38);
  const l2 = at(27, 0.28);
  const boxAt = at(28, 0.0);
  const pillAt = at(28, 0.26);
  const typeAt = at(28, 0.5);
  const clickAt = at(29, 0.12);
  const inboxAt = at(29, 0.3);
  const flyFrom = at(29, 0.55);
  const landAt = at(30, 0.15);
  const typeP = interpolate(frame, [typeAt, typeAt + 22], [0, 1], { easing: theme.ease.inOut, ...clamp });
  const fly = interpolate(frame, [flyFrom, landAt], [0, 1], { easing: theme.ease.inOut, ...clamp });
  const flyOn = frame >= flyFrom && frame < landAt + 2;
  const dot = useSpringAt(landAt, theme.spring.bouncy);
  const land = interpolate(frame, [landAt, landAt + 24], [1, 0], clamp);
  const press = interpolate(frame, [clickAt - 2, clickAt + 2, clickAt + 8], [0, 1, 0], clamp);
  const caret = Math.floor(frame / 12) % 2 === 0 && typeP < 1 ? 1 : 0.0;
  const sx = 1214, sy = 736, ex = 1590, ey = 690;
  const fx = sx + (ex - sx) * fly;
  const fy = sy + (ey - sy) * fly - Math.sin(fly * Math.PI) * 150;
  return (
    <SceneShell noExit>
      <AbsoluteFill>
        {/* headline */}
        <div style={{ position: "absolute", left: 0, right: 0, top: 90, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <WordReveal text="*নিজস্ব* প্রযুক্তির উদ্যোগ" delay={l1} per={5} size={100} align="center" glow />
          <WordReveal text="ও tool তৈরির ~guidelines~" delay={l2} per={5} size={100} align="center" />
        </div>

        {/* centre-piece while the headline is spoken: our own tech + guidelines pack (leaves when the comment box arrives) */}
        <Pop delay={l1 + 4} y={0} from={1} exitAt={boxAt - 6} style={{ position: "absolute", inset: 0 }}>
          <div style={{ position: "absolute", left: 960 - 190, top: 640 - 190 }}>
            <AiOrb size={380} delay={l1 + 4} pulseAt={l2 + 6} />
          </div>
          {[-1, 1].map((side) => (
            <Pop key={side} delay={l2 + 10 + (side > 0 ? 5 : 0)} y={50} x={side * 80} from={0.85} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 960 + side * 340 - 120, top: 520 }}>
              <div style={{ transform: `rotate(${side * 8}deg) translateY(${b.y * side}px)` }}>
                <GlassCard style={{ width: 240, height: 300, borderRadius: 28, padding: 28, display: "flex", flexDirection: "column", gap: 22, border: `1px solid ${theme.colors.primaryLine}` }}>
                  <DocIcon size={72} color={theme.colors.primary} sw={1.5} />
                  <Skel widths={[170, 130, 150, 100]} delay={l2 + 16} h={14} gap={14} />
                </GlassCard>
              </div>
            </Pop>
          ))}
        </Pop>
        {/* labels */}
        <div style={{ position: "absolute", left: 260, top: 522, display: "flex", gap: 18 }}>
          <Pop delay={boxAt} y={20}>
            <Pill size={32}>
              <CommentIcon size={32} color={theme.colors.primary} />
              comment
            </Pill>
          </Pop>
          <Pop delay={pillAt} y={20}>
            <Pill size={32}>এক বাক্যে</Pill>
          </Pop>
        </div>
        {/* composer */}
        <Pop delay={boxAt + 2} y={60} from={0.94} style={{ position: "absolute", left: 260, top: 600 }}>
          <div style={{ transform: `translateY(${b.y}px)` }}>
            <GlassCard style={{ width: 1060, height: 250, borderRadius: theme.radius.lg, padding: "0 44px", display: "flex", alignItems: "center", gap: 36, border: `1px solid ${theme.colors.primaryLine}`, boxShadow: `0 0 80px ${theme.colors.glowSoft}, ${theme.shadow.card}` }}>
              <div style={{ width: 96, height: 96, borderRadius: "50%", background: theme.colors.surface2, border: `1px solid ${theme.colors.lineStrong}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <SparkIcon size={48} color={theme.colors.textDim} />
              </div>
              <div style={{ flex: 1, position: "relative", height: 150, display: "flex", alignItems: "center" }}>
                <div style={{ position: "relative", clipPath: `inset(-20px ${100 - typeP * 100}% -20px 0)`, fontFamily: theme.fonts.display, fontSize: 92, fontWeight: theme.fonts.weight.heavy, lineHeight: theme.lh.hero, letterSpacing: 0, color: theme.colors.primary, textShadow: `0 0 40px ${theme.colors.glow}`, whiteSpace: "nowrap" }}>বাংলাদেশি AI</div>
                <div style={{ width: 5, height: 80, background: theme.colors.primary, marginLeft: 10, opacity: caret, position: "absolute", left: `${typeP * 78}%` }} />
              </div>
              <div style={{ width: 96, height: 96, borderRadius: "50%", background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 40px ${theme.colors.glow}`, transform: `scale(${1 - press * 0.12})`, flexShrink: 0 }}>
                <SendIcon size={46} color={theme.colors.bg} sw={2.2} />
              </div>
            </GlassCard>
          </div>
        </Pop>
        <Cursor frames={[typeAt + 22, clickAt - 4, clickAt]} xs={[930, 1180, 1220]} ys={[820, 760, 750]} clickAt={clickAt} />

        {/* inbox */}
        <Pop delay={inboxAt} y={40} from={0.8} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 1480, top: 580 }}>
          <div style={{ transform: `translateY(${b.y}px) scale(${1 + land * 0.06})` }}>
            <GlassCard style={{ width: 220, height: 220, borderRadius: theme.radius.lg, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 ${50 + land * 60}px ${theme.colors.accentGlow}, ${theme.shadow.card}`, border: `1px solid ${theme.colors.accentLine}` }}>
              <MailIcon size={120} color={theme.colors.accent} sw={1.5} />
              <div style={{ position: "absolute", top: 22, right: 22, width: 34, height: 34, borderRadius: "50%", background: theme.colors.accent, transform: `scale(${Math.min(1.15, dot)})`, boxShadow: `0 0 20px ${theme.colors.accentGlow}` }} />
            </GlassCard>
          </div>
        </Pop>
        <Pop delay={inboxAt + 6} y={16} style={{ position: "absolute", left: 1480, top: 820, width: 220, display: "flex", justifyContent: "center" }}>
          <Pill size={32} accent>inbox</Pill>
        </Pop>
        {/* flying envelope */}
        {flyOn && (
          <div style={{ position: "absolute", left: fx - 48, top: fy - 48, width: 96, height: 96, borderRadius: "50%", background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 50px ${theme.colors.glow}`, transform: `scale(${1 - fly * 0.35}) rotate(${(1 - fly) * -14}deg)` }}>
            <MailIcon size={50} color={theme.colors.bg} sw={2.2} />
          </div>
        )}
        <Sfx name="whoosh" at={l1} v={1} />
        <Sfx name="pop" at={l2} v={2} />
        <Sfx name="pop" at={boxAt + 2} v={5} />
        <Sfx name="click" at={typeAt} v={2} />
        <Sfx name="click" at={clickAt} v={4} />
        <Sfx name="whoosh" at={flyFrom - 2} v={3} />
        <Sfx name="chime" at={landAt} v={6} />
      </AbsoluteFill>
    </SceneShell>
  );
};
