import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { MaskLine, Pop, Sfx, WordReveal, clamp, useBreath, useScene } from "../motion";
import { SceneShell } from "../ui";
import { CheckIcon } from "../icons";

// Scene 3 — "চিন্তা নেই" (Statement card / calm beat). Cues 5-6.
export const Relax: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { at } = useScene();
  const b = useBreath(0.02, 26);
  const showAt = at(5, 0.5);
  const easyAt = at(6, 0.12);
  const forAt = at(6, 0.58);
  const ringP = interpolate(frame, [3, 26], [0, 1], { easing: theme.ease.out, ...clamp });
  const checkP = interpolate(frame, [20, 36], [0, 1], { easing: theme.ease.out, ...clamp });
  const sweep = interpolate(frame, [easyAt + 6, easyAt + 22], [0, 1], { easing: theme.ease.out, ...clamp });
  const R = 100;
  const C = 2 * Math.PI * R;
  return (
    <SceneShell>
      <AbsoluteFill style={{ alignItems: "center" }}>
        {/* ring + check */}
        <Pop delay={0} y={30} from={0.7} cfg={theme.spring.bouncy} style={{ position: "absolute", top: 90 }}>
          <div style={{ width: 240, height: 240, position: "relative", transform: `scale(${b.s}) translateY(${b.y}px)` }}>
            <div style={{ position: "absolute", inset: 20, borderRadius: "50%", background: `radial-gradient(circle, ${theme.colors.glowSoft}, transparent 70%)`, boxShadow: `0 0 50px ${theme.colors.glow}` }} />
            {/* burst rays when the check lands */}
            {Array.from({ length: 14 }).map((_, i) => {
              const p = spring({ frame: frame - 26 - i * 0.8, fps, config: theme.spring.snappy });
              const fade = interpolate(frame, [30, 56], [1, 0], clamp);
              return <div key={i} style={{ position: "absolute", left: 120 - 3, top: 120 - 3, width: 6, height: 34, borderRadius: 6, background: i % 3 === 0 ? theme.colors.accent : theme.colors.primary, opacity: fade * Math.min(1, p), transformOrigin: "3px 3px", transform: `rotate(${(360 / 14) * i}deg) translateY(${R + 22 + p * 42}px)` }} />;
            })}
            <svg width="240" height="240" viewBox="0 0 240 240" style={{ transform: "rotate(-90deg)", position: "absolute" }}>
              <circle cx="120" cy="120" r={R} fill="none" stroke={theme.colors.line} strokeWidth="8" />
              <circle cx="120" cy="120" r={R} fill="none" stroke={theme.colors.primary} strokeWidth="8" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - ringP)} />
            </svg>
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", opacity: checkP, transform: `scale(${0.6 + checkP * 0.4})` }}>
              <CheckIcon size={112} color={theme.colors.text} sw={2.4} />
            </div>
          </div>
        </Pop>

        <div style={{ position: "absolute", top: 380, width: 1500, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
          <WordReveal text="চিন্তা *নেই*" delay={4} per={7} size={230} align="center" glow />
          <Pop delay={showAt} y={30} style={{ marginTop: 6 }}>
            <MaskLine delay={showAt}>
              <div style={{ fontFamily: theme.fonts.display, fontSize: 56, fontWeight: theme.fonts.weight.medium, color: theme.colors.textDim, lineHeight: theme.lh.body, letterSpacing: 0 }}>আজ আমি আপনাদের দেখাবো</div>
            </MaskLine>
          </Pop>
          <div style={{ display: "flex", alignItems: "center", gap: 20, marginTop: 4 }}>
            <Pop delay={easyAt - 2} y={24}>
              <div style={{ position: "relative", padding: "0 26px" }}>
                <div style={{ position: "absolute", inset: "8px 0", borderRadius: 18, background: theme.colors.primary, transformOrigin: "left", transform: `scaleX(${sweep})`, opacity: 0.95, boxShadow: `0 0 50px ${theme.colors.glow}` }} />
                <div style={{ position: "relative", fontFamily: theme.fonts.display, fontSize: 68, fontWeight: theme.fonts.weight.heavy, lineHeight: theme.lh.hero, letterSpacing: 0, color: sweep > 0.55 ? theme.colors.bg : theme.colors.text }}>খুব সহজেই</div>
              </div>
            </Pop>
            <WordReveal text="নিজেদের জন্য" delay={forAt} per={5} size={68} />
          </div>
        </div>
        <Sfx name="whoosh" at={2} v={1} />
        <Sfx name="click" at={34} />
        <Sfx name="pop" at={easyAt + 4} v={4} />
      </AbsoluteFill>
    </SceneShell>
  );
};
