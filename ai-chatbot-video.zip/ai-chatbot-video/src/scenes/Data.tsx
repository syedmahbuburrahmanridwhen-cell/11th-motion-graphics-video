import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, clamp, useBreath, useScene, useSpringAt } from "../motion";
import { AiOrb, GlassCard, Pill, SceneShell, Skel } from "../ui";
import { DbIcon, DocIcon } from "../icons";

// Scene 5 — Process step "File": data → AI flow (hub diagram). Cues 11-13.
const X0 = 700; // flow start (right edge of data card)
const X1 = 1230; // flow end (left edge of orb)
const Y = 640;

export const Data: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const b = useBreath(0.012, 28);
  const dbAt = at(11, 0.3);
  const headAt = at(11, 0.42);
  const flowAt = at(12, 0.05);
  const subAt = at(12, 0.18);
  const orbAt = at(12, 0.5);
  const fileAt = at(13, 0.5);
  const lineP = useSpringAt(flowAt, theme.spring.smooth);
  const landed = frame >= fileAt + 8;
  const dbPulse = interpolate(frame, [fileAt + 8, fileAt + 30], [1, 0], clamp);
  return (
    <SceneShell>
      <AbsoluteFill>
        {/* headline */}
        <div style={{ position: "absolute", left: 150, top: 80 }}>
          <Pop delay={1} y={20}>
            <Pill size={34}>প্রথমে</Pill>
          </Pop>
          <WordReveal text="*data* বা তথ্যভাণ্ডার" delay={headAt} per={5} size={112} glow style={{ marginTop: 6 }} />
          <WordReveal text="যার উপর ভিত্তি করে AI কাজ করবে" delay={subAt} per={4} size={50} weight={theme.fonts.weight.medium} color={theme.colors.textDim} />
        </div>

        {/* data card */}
        <Pop delay={dbAt} y={60} from={0.85} style={{ position: "absolute", left: 360, top: 480 }}>
          <div style={{ transform: `scale(${b.s}) translateY(${b.y}px)` }}>
            <GlassCard style={{ width: 340, height: 340, borderRadius: theme.radius.lg, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 ${60 + dbPulse * 60}px ${theme.colors.glowSoft}, ${theme.shadow.card}` }}>
              <DbIcon size={200} color={theme.colors.primary} sw={1.3} />
            </GlassCard>
          </div>
        </Pop>

        {/* flow line with travelling dots */}
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, opacity: lineP }}>
          <line x1={X0} y1={Y} x2={X0 + (X1 - X0) * lineP} y2={Y} stroke={theme.colors.primaryLine} strokeWidth={3} strokeDasharray="4 14" strokeLinecap="round" strokeDashoffset={-frame * 1.6} />
          {[0, 1, 2].map((k) => {
            const t = ((frame * 0.012 + k / 3) % 1) * lineP;
            return <circle key={k} cx={X0 + (X1 - X0) * t} cy={Y} r={9} fill={k === 0 ? theme.colors.accent : theme.colors.primary} opacity={interpolate(t, [0, 0.1, 0.9, 1], [0, 1, 1, 0], clamp)} />;
          })}
        </svg>

        {/* AI orb */}
        <div style={{ position: "absolute", left: 1230, top: 450 }}>
          <AiOrb size={380} delay={orbAt} pulseAt={fileAt + 10} />
        </div>

        {/* file card drops onto the data card */}
        <Pop delay={fileAt} y={-300} from={1} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 420, top: 420 }}>
          <GlassCard style={{ width: 220, height: 270, borderRadius: 28, padding: 26, display: "flex", flexDirection: "column", gap: 20, alignItems: "flex-start", boxShadow: `0 0 70px ${theme.colors.glow}, ${theme.shadow.card}`, border: `1px solid ${theme.colors.primaryLine}` }}>
            <DocIcon size={72} color={theme.colors.text} sw={1.5} />
            <Skel widths={[170, 130, 150]} delay={fileAt + 6} h={14} gap={14} />
            <div style={{ marginTop: "auto" }}>
              <Pill size={28} hero>file</Pill>
            </div>
          </GlassCard>
        </Pop>
        <Sfx name="pop" at={dbAt} />
        <Sfx name="whoosh" at={headAt} v={3} />
        <Sfx name="pop" at={orbAt} v={5} />
        <Sfx name="thud" at={fileAt + 8} v={2} />
        <Sfx name="chime" at={fileAt + 10} v={2} />
      </AbsoluteFill>
    </SceneShell>
  );
};
