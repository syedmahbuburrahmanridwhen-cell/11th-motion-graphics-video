import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, clamp, useScene } from "../motion";
import { AiOrb, GlassCard, Pill, SceneShell } from "../ui";
import { ChatIcon, SparkIcon } from "../icons";

// Scene 1 — HOOK (Kinetic typography + hero orb). Cues 1-2.
const ORB = { x: 1480, y: 520 };

const OrbitBubble: React.FC<{ i: number; delay: number }> = ({ i, delay }) => {
  const frame = useCurrentFrame();
  const a = (i / 3) * Math.PI * 2 + 0.6 + frame * 0.016;
  const depth = (Math.sin(a) + 1) / 2; // 0 back .. 1 front
  const x = ORB.x + Math.cos(a) * 400 - 80;
  const y = ORB.y + Math.sin(a) * 190 - 50;
  return (
    <Pop delay={delay} y={20} from={0.3} cfg={theme.spring.bouncy} style={{ position: "absolute", left: x, top: y, zIndex: depth > 0.5 ? 3 : 0 }}>
      <div style={{ transform: `scale(${0.78 + depth * 0.4})`, opacity: 0.55 + depth * 0.45 }}>
        <GlassCard style={{ width: 170, height: 104, borderRadius: 30, display: "flex", alignItems: "center", justifyContent: "center", gap: 12 }}>
          {[0, 1, 2].map((d) => (
            <div key={d} style={{ width: 16, height: 16, borderRadius: "50%", background: i === 0 ? theme.colors.primary : theme.colors.textDim, opacity: 0.45 + 0.55 * Math.abs(Math.sin(frame / 8 - d * 0.9 + i)) }} />
          ))}
        </GlassCard>
      </div>
    </Pop>
  );
};

export const Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const aiAt = at(1, 0.4);
  const botAt = at(2, 0.02);
  const pillAt = at(2, 0.5);
  return (
    <SceneShell>
      <AbsoluteFill>
        {/* pulse rings behind the orb */}
        {[0, 1, 2].map((k) => {
          const t = ((frame - 6 - k * 26) % 78) / 78;
          const on = frame > 6 + k * 26;
          return <div key={k} style={{ position: "absolute", left: ORB.x - 260, top: ORB.y - 260, width: 520, height: 520, borderRadius: "50%", border: `2px solid ${theme.colors.primary}`, opacity: on ? (1 - t) * 0.4 : 0, transform: `scale(${0.7 + t * 1.1})` }} />;
        })}
        <div style={{ position: "absolute", left: ORB.x - 260, top: ORB.y - 260 }}>
          <AiOrb size={520} delay={2} pulseAt={aiAt} />
        </div>
        {[0, 1, 2].map((i) => (
          <OrbitBubble key={i} i={i} delay={botAt + i * 5} />
        ))}

        {/* kinetic headline stack */}
        <div style={{ position: "absolute", left: 130, top: 165, width: 1000, display: "flex", flexDirection: "column", gap: 6 }}>
          <Pop delay={1} y={26}>
            <Pill size={32} style={{ marginBottom: 14 }}>
              <ChatIcon size={34} color={theme.colors.primary} />
              ভাই শুনলাম
            </Pill>
          </Pop>
          <WordReveal text="বাংলাদেশও এখন" delay={3} per={4} size={92} />
          <WordReveal text="~নিজস্ব~ ~AI~" delay={aiAt} per={6} size={200} gap={34} style={{ marginTop: -4 }} />
          <WordReveal text="*chatbot* model" delay={botAt} per={5} size={118} glow />
          <Pop delay={pillAt} y={30} from={0.8} cfg={theme.spring.bouncy} style={{ marginTop: 26 }}>
            <Pill size={42} accent>
              <SparkIcon size={40} color={theme.colors.accent} />
              উদ্যোগ নিয়েছে
            </Pill>
          </Pop>
        </div>
        <Sfx name="whoosh" at={0} v={0} />
        <Sfx name="thud" at={aiAt} />
        <Sfx name="pop" at={botAt} v={1} />
        <Sfx name="chime" at={pillAt} />
      </AbsoluteFill>
    </SceneShell>
  );
};
