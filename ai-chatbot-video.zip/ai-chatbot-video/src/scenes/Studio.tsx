import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, clamp, useBreath, useScene, useSpringAt } from "../motion";
import { Cursor, GlassCard, LogoTile, Pill, SceneShell, Skel, WindowFrame } from "../ui";
import { ArrowRight, DocIcon, PlusIcon, SendIcon, UploadIcon } from "../icons";

// Scene 6 — Google AI Studio: logo reveal → UI mockup (New App → upload file → prompt). Cues 14-17.
const WIN = { x: 180, y: 130, w: 1560, h: 690 }; // body origin = (x, y + 64)
const SIDE_W = 330;
const BOX = { x: 360 + 150, y: 380, w: 930, h: 190 }; // chat box in window-body coordinates

export const Studio: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const b = useBreath(0.01, 30);
  const goAt = 0;
  const logoAt = at(14, 0.36);
  const nameAt = at(14, 0.5);
  const winAt = at(15, 0) - 2;
  const moveAt = at(15, 0) - 4;
  const clickAt = at(15, 0.55);
  const boxAt = at(16, 0.02);
  const fileAt = at(16, 0.36);
  const promptAt = at(17, 0.0);
  const typeAt = at(17, 0.28);

  // logo: big centre → small title-bar icon
  const tp = interpolate(frame, [moveAt, moveAt + 24], [0, 1], { easing: theme.ease.inOut, ...clamp });
  const logoSize = interpolate(tp, [0, 1], [300, 44]);
  const logoCx = interpolate(tp, [0, 1], [960, WIN.x + 132]); // title-bar slot, left of the "Google AI Studio" label
  const logoCy = interpolate(tp, [0, 1], [440 + b.y, WIN.y + 32]);
  const nameOpacity = interpolate(frame, [moveAt - 14, moveAt - 2], [1, 0], clamp);

  const ring = interpolate(frame, [logoAt, logoAt + 28], [0, 1], { easing: theme.ease.out, ...clamp });
  const newAppOn = frame >= clickAt;
  const boxFocus = interpolate(frame, [boxAt, boxAt + 10], [0, 1], clamp);
  const fileP = useSpringAt(fileAt, theme.spring.smooth);
  const fileLanded = frame >= fileAt + 18;
  const caret = Math.floor(frame / 12) % 2 === 0 ? 1 : 0.15;

  return (
    <SceneShell>
      <AbsoluteFill>
        {/* phase A: "চলে যাবেন" + logo reveal */}
        <Pop delay={goAt} y={30} exitAt={moveAt - 16} style={{ position: "absolute", left: 0, right: 0, top: 150, display: "flex", justifyContent: "center" }}>
          <Pill size={40}>
            চলে যাবেন
            <ArrowRight size={40} color={theme.colors.primary} sw={2.2} style={{ transform: `translateX(${Math.sin(frame / 6) * 6}px)` }} />
          </Pill>
        </Pop>
        {/* burst rings behind the logo */}
        {[0, 1].map((k) => {
          const t = interpolate(frame, [logoAt + k * 6, logoAt + 34 + k * 6], [0, 1], { easing: theme.ease.out, ...clamp });
          return <div key={k} style={{ position: "absolute", left: 960 - 200, top: 440 - 200, width: 400, height: 400, borderRadius: "50%", border: `3px solid ${k ? theme.colors.accent : theme.colors.primary}`, opacity: (1 - t) * (tp < 0.5 ? 0.7 : 0), transform: `scale(${0.8 + t * 1.6})` }} />;
        })}
        <div style={{ position: "absolute", left: 960 - 330, top: 440 - 330, width: 660, height: 660, borderRadius: "50%", background: `radial-gradient(circle, ${theme.colors.glowSoft}, transparent 65%)`, opacity: ring * (1 - tp) }} />
        <div style={{ position: "absolute", left: 0, right: 0, top: 640, display: "flex", justifyContent: "center", opacity: nameOpacity }}>
          <WordReveal text="Google AI Studio" delay={nameAt} per={6} size={104} align="center" />
        </div>

        {/* phase B: app window */}
        <Pop delay={winAt} y={60} from={0.94} style={{ position: "absolute", left: WIN.x, top: WIN.y }}>
          <div style={{ transform: `scale(${b.s})` }}>
            <WindowFrame
              width={WIN.w}
              height={WIN.h}
              title={
                <div style={{ display: "flex", alignItems: "center", gap: 14, marginLeft: 72 }}>
                  <div style={{ fontFamily: theme.fonts.display, fontSize: 28, fontWeight: theme.fonts.weight.heavy, color: theme.colors.text, lineHeight: 1.4 }}>Google AI Studio</div>
                </div>
              }
            >
              {/* sidebar */}
              <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: SIDE_W, borderRight: `1px solid ${theme.colors.line}`, background: theme.colors.panel, padding: 28, display: "flex", flexDirection: "column", gap: 26 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 16, height: 72, padding: "0 22px", borderRadius: 20, background: newAppOn ? theme.colors.primary : theme.colors.surface2, border: `1px solid ${newAppOn ? theme.colors.primary : theme.colors.lineStrong}`, boxShadow: newAppOn ? `0 0 40px ${theme.colors.glow}` : undefined }}>
                  <PlusIcon size={32} color={newAppOn ? theme.colors.bg : theme.colors.text} sw={2.4} />
                  <div style={{ fontFamily: theme.fonts.display, fontSize: 34, fontWeight: theme.fonts.weight.heavy, color: newAppOn ? theme.colors.bg : theme.colors.text, lineHeight: 1.4 }}>New App</div>
                </div>
                <Skel widths={[220, 170, 240, 150, 200]} delay={winAt + 10} h={16} gap={30} />
              </div>
              {/* main canvas */}
              <div style={{ position: "absolute", left: SIDE_W, right: 0, top: 0, bottom: 0 }}>
                <div style={{ position: "absolute", left: 100, top: 70 }}>
                  <Skel widths={[460, 320]} delay={winAt + 16} h={26} gap={20} color={theme.colors.line} />
                </div>
                {/* chat box */}
                <div style={{ position: "absolute", left: 150, top: 330, width: 930, height: 190, borderRadius: 34, background: theme.colors.surface, border: `2px solid ${boxFocus > 0.5 ? theme.colors.primary : theme.colors.lineStrong}`, boxShadow: boxFocus > 0 ? `0 0 ${50 * boxFocus}px ${theme.colors.glow}` : undefined, padding: 28 }}>
                  {frame >= promptAt - 2 ? (
                    <div style={{ display: "flex", alignItems: "flex-start", gap: 8, marginLeft: fileLanded ? 0 : 0 }}>
                      <div style={{ paddingTop: fileLanded ? 70 : 6, marginLeft: 64 }}>
                        <Skel widths={[640, 540]} delay={typeAt} h={20} gap={18} color={theme.colors.primaryLine} />
                      </div>
                      <div style={{ width: 4, height: 34, background: theme.colors.primary, opacity: caret, marginTop: fileLanded ? 70 : 2, marginLeft: 0 }} />
                    </div>
                  ) : null}
                  <div style={{ position: "absolute", right: 24, bottom: 22, width: 58, height: 58, borderRadius: "50%", background: frame >= promptAt ? theme.colors.primary : theme.colors.surface2, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <SendIcon size={28} color={frame >= promptAt ? theme.colors.bg : theme.colors.textDim} sw={2.2} />
                  </div>
                  <div style={{ position: "absolute", left: 24, bottom: 24 }}>
                    <UploadIcon size={40} color={theme.colors.textDim} sw={1.8} />
                  </div>
                </div>
                {/* labels */}
                <Pop delay={boxAt} y={16} style={{ position: "absolute", left: 150, top: 262 }}>
                  <Pill size={28}>chat box</Pill>
                </Pop>
                <Pop delay={promptAt} y={16} style={{ position: "absolute", left: 330, top: 262 }}>
                  <Pill size={28} hero>prompt</Pill>
                </Pop>
                {/* file chip flies into the chat box */}
                <div style={{ position: "absolute", left: 180, top: 350, opacity: fileP, transform: `translate(${interpolate(fileP, [0, 1], [-120, 0])}px, ${interpolate(fileP, [0, 1], [-250, 0])}px) scale(${interpolate(fileP, [0, 1], [1.25, 1])})` }}>
                  <GlassCard style={{ display: "flex", alignItems: "center", gap: 14, height: 66, padding: "0 24px 0 18px", borderRadius: 22, border: `1px solid ${theme.colors.primaryLine}`, boxShadow: `0 0 40px ${theme.colors.glowSoft}, ${theme.shadow.float}` }}>
                    <DocIcon size={38} color={theme.colors.primary} />
                    <div style={{ fontFamily: theme.fonts.display, fontSize: 30, fontWeight: theme.fonts.weight.heavy, color: theme.colors.text, lineHeight: 1.4 }}>file</div>
                  </GlassCard>
                </div>
              </div>
              <Cursor frames={[winAt + 18, clickAt - 12, clickAt]} xs={[1250, 560, 160]} ys={[560, 330, 66]} clickAt={clickAt} />
            </WindowFrame>
          </div>
        </Pop>

        {/* logo (flies from centre to the title bar) */}
        <div style={{ position: "absolute", left: logoCx - logoSize / 2, top: logoCy - logoSize / 2, transformOrigin: "50% 50%" }}>
          <Pop delay={logoAt} y={0} from={0.2} cfg={theme.spring.bouncy}>
            <LogoTile size={logoSize} glow={tp < 0.5} />
          </Pop>
        </div>
        <Sfx name="whoosh" at={goAt} v={4} />
        <Sfx name="chime" at={logoAt} v={3} />
        <Sfx name="pop" at={winAt + 2} v={1} />
        <Sfx name="click" at={clickAt} v={1} />
        <Sfx name="pop" at={fileAt + 12} v={5} />
        <Sfx name="click" at={typeAt} v={3} />
      </AbsoluteFill>
    </SceneShell>
  );
};
