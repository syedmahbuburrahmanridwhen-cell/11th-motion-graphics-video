import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, useBreath, useScene } from "../motion";
import { GlassCard, Skel, SceneShell, WindowFrame, Pill } from "../ui";
import { SendIcon, SparkIcon, ChatIcon } from "../icons";

// Scene 4 — Glossy UI mockup: a human-like chat (+ key phrases + FREE stamp). Cues 7-10.
const Bubble: React.FC<{ side: "user" | "ai"; widths: number[]; delay: number; w: number; top: number; typingUntil?: number }> = ({ side, widths, delay, w, top, typingUntil }) => {
  const frame = useCurrentFrame();
  const typing = typingUntil !== undefined && frame < typingUntil;
  return (
    <Pop delay={delay} y={26} from={0.9} cfg={theme.spring.snappy} style={{ position: "absolute", top, [side === "user" ? "right" : "left"]: 40, width: w }}>
      <div style={{ padding: "26px 30px", borderRadius: 30, background: side === "user" ? theme.colors.primaryTint : theme.colors.panel, border: `1px solid ${side === "user" ? theme.colors.primaryLine : theme.colors.line}` }}>
        {typing ? (
          <div style={{ display: "flex", gap: 12, height: 40, alignItems: "center" }}>
            {[0, 1, 2].map((d) => (
              <div key={d} style={{ width: 16, height: 16, borderRadius: "50%", background: theme.colors.textDim, opacity: 0.35 + 0.65 * Math.abs(Math.sin(frame / 6 - d * 0.8)) }} />
            ))}
          </div>
        ) : (
          <Skel widths={widths} delay={typingUntil ?? delay} color={side === "user" ? theme.colors.primaryLine : theme.colors.lineStrong} />
        )}
      </div>
    </Pop>
  );
};

export const Chat: React.FC = () => {
  const { at } = useScene();
  const b = useBreath(0.006, 34);
  const winAt = 1;
  const u1 = at(8, 0.02);
  const a1 = at(8, 0.32);
  const u2 = at(9, 0.12);
  const a2 = at(9, 0.4);
  const chip1 = at(7, 0.3);
  const chip2 = at(8, 0.52);
  const chip3 = at(9, 0.04);
  const free = at(10, 0.0);
  return (
    <SceneShell>
      <AbsoluteFill>
        <Pop delay={winAt} y={70} from={0.92} style={{ position: "absolute", left: 130, top: 170 }}>
          <div style={{ transform: `scale(${b.s}) translateY(${b.y}px)` }}>
            <WindowFrame
              width={940}
              height={740}
              title={
                <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
                  <div style={{ width: 34, height: 34, borderRadius: "50%", background: `radial-gradient(circle at 34% 28%, ${theme.colors.text}, ${theme.colors.primary} 50%, ${theme.colors.surface2})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <SparkIcon size={18} color={theme.colors.bg} sw={2.4} />
                  </div>
                  <div style={{ fontFamily: theme.fonts.display, fontSize: 28, fontWeight: theme.fonts.weight.heavy, color: theme.colors.text, lineHeight: 1.4 }}>AI chatbot</div>
                  <div style={{ width: 12, height: 12, borderRadius: "50%", background: theme.colors.accent, boxShadow: `0 0 14px ${theme.colors.accentGlow}` }} />
                </div>
              }
            >
              <Bubble side="user" widths={[300, 210]} delay={u1} w={400} top={28} />
              <Bubble side="ai" widths={[520, 470, 330]} delay={a1} typingUntil={a1 + 22} w={640} top={160} />
              <Bubble side="user" widths={[260]} delay={u2} w={330} top={372} />
              <Bubble side="ai" widths={[480, 380]} delay={a2} typingUntil={a2 + 22} w={600} top={472} />
              {/* input bar */}
              <div style={{ position: "absolute", left: 36, right: 36, bottom: 24, height: 64, borderRadius: 32, background: theme.colors.panel, border: `1px solid ${theme.colors.line}`, display: "flex", alignItems: "center", padding: "0 12px 0 30px", justifyContent: "space-between" }}>
                <Skel widths={[260]} h={14} />
                <div style={{ width: 46, height: 46, borderRadius: "50%", background: theme.colors.primary, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 26px ${theme.colors.glow}` }}>
                  <SendIcon size={24} color={theme.colors.bg} sw={2.2} />
                </div>
              </div>
            </WindowFrame>
          </div>
        </Pop>

        {/* key phrases */}
        <div style={{ position: "absolute", left: 1130, top: 215, width: 720, display: "flex", flexDirection: "column", gap: 12 }}>
          <Pop delay={chip1 - 4} y={20}>
            <Pill size={32}>
              <ChatIcon size={34} color={theme.colors.primary} />
              নিজের জন্য
            </Pill>
          </Pop>
          <WordReveal text="*AI chatbot*" delay={chip1} per={5} size={104} glow />
          <WordReveal text="বা tool" delay={chip1 + 8} per={5} size={60} color={theme.colors.textDim} />
          <WordReveal text="মানুষের মতো" delay={chip2} per={5} size={72} style={{ marginTop: 18 }} />
          <WordReveal text="নিখুঁতভাবে chat" delay={chip3} per={5} size={72} />
        </div>
        {/* FREE stamp */}
        <Pop delay={free} y={0} from={1.7} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 1150, top: 800 }}>
          <div style={{ transform: "rotate(-4deg)", display: "inline-flex", alignItems: "baseline", gap: 18, padding: "10px 46px 18px", borderRadius: 30, border: `4px solid ${theme.colors.accent}`, background: theme.colors.accentTint, boxShadow: `0 0 70px ${theme.colors.accentGlow}`, fontFamily: theme.fonts.display, fontWeight: theme.fonts.weight.heavy, lineHeight: theme.lh.hero, letterSpacing: 0, color: theme.colors.accent }}>
            <span style={{ fontSize: 70 }}>সম্পূর্ণ</span>
            <span style={{ fontSize: 120 }}>free</span>
          </div>
        </Pop>
        <Sfx name="pop" at={winAt} />
        <Sfx name="pop" at={a1 + 22} v={2} />
        <Sfx name="whoosh" at={chip1} v={2} />
        <Sfx name="pop" at={a2 + 22} v={4} />
        <Sfx name="thud" at={free} v={1} />
        <Sfx name="chime" at={free + 6} v={1} />
      </AbsoluteFill>
    </SceneShell>
  );
};
