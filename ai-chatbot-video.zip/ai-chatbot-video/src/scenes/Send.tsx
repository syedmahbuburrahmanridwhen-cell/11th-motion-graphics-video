import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, clamp, useBreath, useScene, useSpringAt } from "../motion";
import { AiOrb, Cursor, GlassCard, Pill, SceneShell } from "../ui";
import { CheckIcon, ChatIcon, DocIcon, LockIcon, SendIcon } from "../icons";

// Scene 8 — Process step "Send": checklist → send click → build progress. Cues 22-23.
const Row: React.FC<{ icon: React.ReactNode; label: string; delay: number; tickAt: number }> = ({ icon, label, delay, tickAt }) => {
  const tick = useSpringAt(tickAt, theme.spring.bouncy);
  return (
    <Pop delay={delay} y={30} x={-40} cfg={theme.spring.snappy}>
      <div style={{ display: "flex", alignItems: "center", gap: 26, height: 124, padding: "0 32px", borderRadius: 26, background: theme.colors.panel, border: `1px solid ${theme.colors.line}` }}>
        <div style={{ width: 70, height: 70, borderRadius: 20, background: theme.colors.primaryTint, border: `1px solid ${theme.colors.primaryLine}`, display: "flex", alignItems: "center", justifyContent: "center" }}>{icon}</div>
        <div style={{ flex: 1, fontFamily: theme.fonts.display, fontSize: 48, fontWeight: theme.fonts.weight.heavy, color: theme.colors.text, lineHeight: theme.lh.body, letterSpacing: 0 }}>{label}</div>
        <div style={{ width: 62, height: 62, borderRadius: "50%", background: tick > 0.05 ? theme.colors.accent : "transparent", border: `2px solid ${tick > 0.05 ? theme.colors.accent : theme.colors.lineStrong}`, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${0.6 + 0.4 * Math.min(1.1, tick)})`, boxShadow: tick > 0.5 ? `0 0 26px ${theme.colors.accentGlow}` : undefined }}>
          <CheckIcon size={36} color={theme.colors.bg} sw={3.2} style={{ opacity: Math.min(1, tick * 1.6) }} />
        </div>
      </div>
    </Pop>
  );
};

export const Send: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const { at } = useScene();
  const b = useBreath(0.012, 24);
  const t1 = at(22, 0.08);
  const t2 = at(22, 0.2);
  const t3 = at(22, 0.32);
  const clickAt = at(22, 0.66);
  const buildAt = at(23, 0.0);
  const textAt = at(23, 0.45);
  const btnOut = interpolate(frame, [clickAt + 4, clickAt + 14], [0, 1], { easing: theme.ease.in, ...clamp });
  const press = interpolate(frame, [clickAt - 2, clickAt + 2, clickAt + 8], [0, 1, 0], clamp);
  const prog = interpolate(frame, [clickAt + 10, durationInFrames - 6], [0, 0.97], { easing: theme.ease.inOut, ...clamp });
  const R = 190;
  const C = 2 * Math.PI * R;
  return (
    <SceneShell>
      <AbsoluteFill>
        <div style={{ position: "absolute", left: 150, top: 120, width: 800 }}>
          <WordReveal text="সবকিছু *set*" delay={1} per={6} size={104} glow />
        </div>
        <div style={{ position: "absolute", left: 150, top: 290, width: 760, display: "flex", flexDirection: "column", gap: 22 }}>
          <Row icon={<DocIcon size={40} color={theme.colors.primary} />} label="file" delay={6} tickAt={t1} />
          <Row icon={<ChatIcon size={40} color={theme.colors.primary} />} label="prompt" delay={11} tickAt={t2} />
          <Row icon={<LockIcon size={40} color={theme.colors.primary} />} label="guidelines" delay={16} tickAt={t3} />
        </div>

        {/* send button → progress ring + forming orb */}
        <div style={{ position: "absolute", left: 1400 - 220, top: 430 - 220, width: 440, height: 440 }}>
          <Pop delay={at(22, 0.3)} y={40} from={0.6} cfg={theme.spring.bouncy} style={{ position: "absolute", inset: 0, opacity: undefined }}>
            <div style={{ position: "absolute", inset: 70, borderRadius: "50%", background: `radial-gradient(circle at 34% 28%, ${theme.colors.text}, ${theme.colors.primary} 40%, ${theme.colors.surface2} 130%)`, boxShadow: `0 0 70px ${theme.colors.glow}`, display: "flex", alignItems: "center", justifyContent: "center", opacity: 1 - btnOut, transform: `scale(${(1 - press * 0.1) * (1 - btnOut * 0.35) * b.s})` }}>
              <SendIcon size={120} color={theme.colors.bg} sw={2} />
            </div>
          </Pop>
          <div style={{ position: "absolute", inset: 0, opacity: btnOut }}>
            <svg width={440} height={440} viewBox="0 0 440 440" style={{ position: "absolute", inset: 0, transform: "rotate(-90deg)" }}>
              <circle cx={220} cy={220} r={R} fill="none" stroke={theme.colors.line} strokeWidth={12} />
              <circle cx={220} cy={220} r={R} fill="none" stroke={theme.colors.primary} strokeWidth={12} strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - prog)} style={{ filter: `drop-shadow(0 0 12px ${theme.colors.glow})` }} />
            </svg>
            <div style={{ position: "absolute", left: 220 - 150, top: 220 - 150, opacity: interpolate(frame, [clickAt + 12, clickAt + 30], [0, 1], clamp), transform: `scale(${0.55 + 0.45 * interpolate(prog, [0, 0.9], [0, 1], clamp)})` }}>
              <AiOrb size={300} delay={clickAt + 10} />
            </div>
          </div>
        </div>
        <Cursor frames={[at(22, 0.35), clickAt - 4, clickAt]} xs={[1150, 1380, 1410]} ys={[760, 470, 460]} clickAt={clickAt} />

        <Pop delay={buildAt} y={24} style={{ position: "absolute", left: 1150, top: 700, width: 500, display: "flex", justifyContent: "center" }}>
          <Pill size={32}>কিছুক্ষণ পর</Pill>
        </Pop>
        <WordReveal text="নিজের *AI chatbot*" delay={textAt} per={5} size={62} align="center" style={{ position: "absolute", left: 1000, top: 765, width: 800 }} />
        <Sfx name="click" at={t1} v={1} />
        <Sfx name="click" at={t2} v={3} />
        <Sfx name="click" at={t3} v={5} />
        <Sfx name="click" at={clickAt} v={2} />
        <Sfx name="whoosh" at={clickAt + 6} v={6} />
        <Sfx name="pop" at={clickAt + 14} v={3} />
      </AbsoluteFill>
    </SceneShell>
  );
};
