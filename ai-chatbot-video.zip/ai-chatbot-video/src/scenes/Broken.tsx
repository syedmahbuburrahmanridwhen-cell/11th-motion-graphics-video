import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Pop, Sfx, WordReveal, clamp, useBreath, useScene } from "../motion";
import { GlassCard, Pill, SceneShell, WindowFrame } from "../ui";
import { GlobeIcon, QuestionIcon, ChatIcon } from "../icons";

// Scene 2 — Broken website (UI mockup + irony reveal). Cues 3-4.
const Block: React.FC<{ w: number; h: number; seed: number; glitch: number; hero?: boolean }> = ({ w, h, seed, glitch, hero }) => {
  const frame = useCurrentFrame();
  const j = glitch * Math.sin(frame * 3.1 + seed * 7) * 14;
  return (
    <div style={{ position: "relative", width: w, height: h, transform: `translateX(${j}px)` }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: 18, background: theme.colors.line, transform: `translateX(${glitch * 6}px)`, opacity: glitch * 0.8, border: `1px solid ${theme.colors.primary}` }} />
      <div style={{ position: "absolute", inset: 0, borderRadius: 18, background: hero ? theme.colors.surface2 : theme.colors.line, border: `1px solid ${theme.colors.line}` }} />
    </div>
  );
};

export const Broken: React.FC = () => {
  const frame = useCurrentFrame();
  const { at } = useScene();
  const b = useBreath(0.008, 30);
  const winAt = 2;
  const nameAt = at(3, 0.3);
  const notAt = at(3, 0.72);
  const botAt = at(4, 0.28);
  const bubbleAt = at(4, 0.5);
  const glitch = frame % 46 < 5 ? 1 : frame % 97 < 3 ? 0.6 : 0;
  const strike = interpolate(frame, [notAt + 10, notAt + 24], [0, 1], { easing: theme.ease.out, ...clamp });
  const stuck = 0.32 + Math.sin(frame / 5) * 0.012;
  return (
    <SceneShell>
      <AbsoluteFill>
        <Pop delay={winAt} y={70} from={0.9} cfg={theme.spring.smooth} style={{ position: "absolute", left: 130, top: 200 }}>
          <div style={{ transform: `scale(${b.s}) translateY(${b.y}px)` }}>
            <WindowFrame
              width={1030}
              height={680}
              title={
                <div style={{ display: "flex", alignItems: "center", gap: 14, padding: "8px 26px", borderRadius: 999, background: theme.colors.line, fontFamily: theme.fonts.display, fontSize: 26, fontWeight: theme.fonts.weight.medium, color: theme.colors.textDim, lineHeight: 1.4 }}>
                  <GlobeIcon size={28} color={theme.colors.textDim} />
                  website
                </div>
              }
            >
              <div style={{ position: "absolute", inset: 0, padding: 36, display: "flex", flexDirection: "column", gap: 24 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <Block w={190} h={34} seed={1} glitch={glitch} />
                  <div style={{ display: "flex", gap: 16 }}>
                    <Block w={80} h={26} seed={2} glitch={glitch} />
                    <Block w={80} h={26} seed={3} glitch={glitch} />
                    <Block w={80} h={26} seed={4} glitch={glitch} />
                  </div>
                </div>
                <Block w={958} h={230} seed={5} glitch={glitch} hero />
                <div style={{ display: "flex", gap: 24 }}>
                  <Block w={300} h={140} seed={6} glitch={glitch} />
                  <Block w={300} h={140} seed={7} glitch={glitch} />
                  <Block w={300} h={140} seed={8} glitch={glitch} />
                </div>
              </div>
              {/* stuck loader */}
              <div style={{ position: "absolute", left: 0, right: 0, top: 150, display: "flex", flexDirection: "column", alignItems: "center", gap: 22 }}>
                <svg width="120" height="120" viewBox="0 0 120 120" style={{ transform: `rotate(${frame * 7}deg)` }}>
                  <circle cx="60" cy="60" r="46" fill="none" stroke={theme.colors.line} strokeWidth="9" />
                  <circle cx="60" cy="60" r="46" fill="none" stroke={theme.colors.textDim} strokeWidth="9" strokeLinecap="round" strokeDasharray="70 220" />
                </svg>
                <div style={{ width: 360, height: 12, borderRadius: 12, background: theme.colors.line, overflow: "hidden" }}>
                  <div style={{ width: `${stuck * 100}%`, height: "100%", background: theme.colors.textDim, borderRadius: 12 }} />
                </div>
              </div>
            </WindowFrame>
          </div>
        </Pop>

        {/* chatbot bubble pops over the stuck page */}
        <Pop delay={bubbleAt} y={50} from={0.4} cfg={theme.spring.bouncy} style={{ position: "absolute", left: 880, top: 730 }}>
          <div style={{ transform: `translateY(${b.y * 1.5}px)` }}>
            <GlassCard style={{ width: 330, height: 150, borderRadius: 40, display: "flex", alignItems: "center", justifyContent: "center", gap: 16, boxShadow: `0 0 70px ${theme.colors.glowSoft}, ${theme.shadow.card}` }}>
              <ChatIcon size={52} color={theme.colors.primary} />
              {[0, 1, 2].map((d) => (
                <div key={d} style={{ width: 18, height: 18, borderRadius: "50%", background: theme.colors.primary, opacity: 0.4 + 0.6 * Math.abs(Math.sin(frame / 7 - d)) }} />
              ))}
            </GlassCard>
          </div>
        </Pop>

        {/* copy column */}
        <div style={{ position: "absolute", left: 1200, top: 290, width: 660, display: "flex", flexDirection: "column", gap: 14 }}>
          <WordReveal text="নিজেদের website" delay={nameAt} per={5} size={78} />
          <div style={{ position: "relative", width: "fit-content" }}>
            <WordReveal text="ঠিকমতো কাজ করে না" delay={notAt} per={4} size={66} color={theme.colors.textDim} />
            <div style={{ position: "absolute", left: 0, top: "56%", height: 5, width: `${strike * 100}%`, background: theme.colors.primary, borderRadius: 5, boxShadow: `0 0 20px ${theme.colors.glow}` }} />
          </div>
          <Pop delay={botAt - 4} y={20} style={{ marginTop: 36 }}>
            <Pill size={34}>
              <QuestionIcon size={34} color={theme.colors.primary} />
              তারা নাকি
            </Pill>
          </Pop>
          <WordReveal text="*chatbot* বানাবে" delay={botAt} per={5} size={92} glow />
        </div>
        <Sfx name="pop" at={winAt} />
        <Sfx name="click" at={notAt + 10} v={2} />
        <Sfx name="pop" at={bubbleAt} v={3} />
      </AbsoluteFill>
    </SceneShell>
  );
};
