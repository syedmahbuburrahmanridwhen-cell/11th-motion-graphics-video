import React, { useEffect, useState } from "react";
import { Audio, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_FILE, VOICEOVER_IN_RENDER, VOICEOVER_IN_STUDIO } from "./config";

/**
 * Plays public/voiceover.mp3 for sync-checking if (and only if) the file exists.
 * Flags live in config.ts. Default: on in Studio preview, off in final render.
 */
export const PreviewAudio: React.FC = () => {
  const enabled = getRemotionEnvironment().isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_STUDIO;
  const [exists, setExists] = useState(false);
  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    fetch(staticFile(VOICEOVER_FILE))
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive && r.ok && !type.includes("text/html")) setExists(true);
        r.body?.cancel();
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [enabled]);
  if (!enabled || !exists) return null;
  return <Audio src={staticFile(VOICEOVER_FILE)} volume={1} />;
};
