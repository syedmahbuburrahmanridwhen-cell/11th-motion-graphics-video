import React from "react";
import { AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { Pop, clamp, useBreath, useSpringAt } from "./motion";
import { SparkIcon, CheckIcon, CursorIcon } from "./icons";
import { cueFrame, scenes } from "./timeline";
import { LEAD_FRAMES } from "./config";

/* ---------- shared surfaces ---------- */
export const glass = (extra?: React.CSSProperties): React.CSSProperties => ({
  background: `linear-gradient(160deg, ${theme.colors.surface2}, ${theme.colors.surface})`,
  border: `1px solid ${theme.colors.line}`,
  borderRadius: theme.radius.md,
  boxShadow: theme.shadow.card,
  position: "relative",
  ...extra,
});

/** Glass card with a lit top edge. */
export const GlassCard: React.FC<{ style?: React.CSSProperties; children?: React.ReactNode }> = ({ style, children }) => (
  <div style={glass(style)}>
    <div style={{ position: "absolute", top: 0, left: 24, right: 24, height: 1, background: `linear-gradient(90deg, transparent, ${theme.colors.lineStrong}, transparent)` }} />
    {children}
  </div>
);

export const Label: React.FC<{ children: React.ReactNode; size?: number; color?: string; weight?: number; style?: React.CSSProperties }> = ({ children, size = 34, color = theme.colors.text, weight = theme.fonts.weight.heavy, style }) => (
  <div style={{ fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight, lineHeight: theme.lh.body, letterSpacing: 0, color, ...style }}>{children}</div>
);

export const Pill: React.FC<{ children: React.ReactNode; size?: number; hero?: boolean; accent?: boolean; style?: React.CSSProperties }> = ({ children, size = 30, hero, accent, style }) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 12,
      padding: `${size * 0.22}px ${size * 0.7}px`,
      borderRadius: theme.radius.pill,
      fontFamily: theme.fonts.display,
      fontWeight: theme.fonts.weight.heavy,
      fontSize: size,
      lineHeight: theme.lh.body,
      letterSpacing: 0,
      color: hero ? theme.colors.bg : accent ? theme.colors.accent : theme.colors.text,
      background: hero ? theme.colors.primary : accent ? theme.colors.accentTint : theme.colors.panel,
      border: `1px solid ${hero ? theme.colors.primary : accent ? theme.colors.accentLine : theme.colors.line}`,
      boxShadow: hero ? `0 0 40px ${theme.colors.glow}` : undefined,
      whiteSpace: "nowrap",
      ...style,
    }}
  >
    {children}
  </div>
);

/* ---------- scene exit wrapper (exits are faster than entrances) ---------- */
export const SceneShell: React.FC<{ children: React.ReactNode; noExit?: boolean }> = ({ children, noExit }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const ex = noExit ? 0 : interpolate(frame, [durationInFrames - 9, durationInFrames - 1], [0, 1], { easing: theme.ease.in, ...clamp });
  return (
    <AbsoluteFill style={{ opacity: 1 - ex * 0.6, transform: `scale(${1 - ex * 0.035})`, filter: ex > 0.02 ? `blur(${ex * 5}px)` : undefined }}>{children}</AbsoluteFill>
  );
};

/* ---------- AI orb: glossy sphere + counter-rotating rings + orbiting dots ---------- */
export const AiOrb: React.FC<{ size: number; delay?: number; pulseAt?: number; style?: React.CSSProperties }> = ({ size, delay = 0, pulseAt, style }) => {
  const frame = useCurrentFrame();
  const b = useBreath(0.025, 24);
  const pulse = pulseAt === undefined ? 0 : Math.max(0, 1 - (frame - pulseAt) / 22) * (frame >= pulseAt ? 1 : 0);
  const r = size / 2;
  return (
    <Pop delay={delay} y={0} from={0.4} cfg={theme.spring.bouncy} style={{ width: size, height: size, position: "relative", ...style }}>
      <div style={{ position: "absolute", inset: 0, transform: `scale(${b.s + pulse * 0.08}) translateY(${b.y}px)` }}>
        {/* glow is a radial-gradient (not a giant box-shadow, which Chromium clips to the layer bounds) */}
        <div style={{ position: "absolute", inset: -size * 0.45, borderRadius: "50%", background: `radial-gradient(circle, ${theme.colors.glow} 0%, ${theme.colors.glowSoft} 34%, transparent 66%)`, opacity: 0.8 + pulse * 0.2 }} />
        <div style={{ position: "absolute", inset: size * 0.14, borderRadius: "50%", background: `radial-gradient(circle at 34% 28%, ${theme.colors.text}, ${theme.colors.primary} 36%, ${theme.colors.surface2} 100%)`, boxShadow: `inset 0 -${size * 0.05}px ${size * 0.1}px rgba(0,0,0,0.5)` }} />
        <div style={{ position: "absolute", inset: size * 0.14, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <SparkIcon size={size * 0.36} color={theme.colors.bg} sw={2.2} />
        </div>
        <svg width={size} height={size} style={{ position: "absolute", inset: 0, overflow: "visible", transform: `rotate(${frame * 0.5}deg)` }}>
          <circle cx={r} cy={r} r={r - 3} fill="none" stroke={theme.colors.primary} strokeOpacity={0.55} strokeWidth={2} strokeDasharray="4 14" strokeLinecap="round" />
          <circle cx={r + (r - 3)} cy={r} r={size * 0.025} fill={theme.colors.accent} />
        </svg>
        <svg width={size} height={size} style={{ position: "absolute", inset: 0, overflow: "visible", transform: `rotate(${-frame * 0.32}deg) scale(0.86)` }}>
          <circle cx={r} cy={r} r={r - 3} fill="none" stroke={theme.colors.text} strokeOpacity={0.25} strokeWidth={1.5} strokeDasharray="2 10" strokeLinecap="round" />
        </svg>
      </div>
    </Pop>
  );
};

/* ---------- skeleton text lines that sweep in (no invented copy inside UI mockups) ---------- */
export const Skel: React.FC<{ widths: number[]; delay?: number; h?: number; gap?: number; color?: string; per?: number }> = ({ widths, delay = 0, h = 16, gap = 14, color = theme.colors.lineStrong, per = 5 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ display: "flex", flexDirection: "column", gap }}>
      {widths.map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.smooth });
        return <div key={i} style={{ height: h, width: w * p, borderRadius: h, background: color, opacity: Math.min(1, p * 2) }} />;
      })}
    </div>
  );
};

/* ---------- the uploaded Google AI Studio logo, undistorted, as an app-icon tile ---------- */
export const LogoTile: React.FC<{ size: number; glow?: boolean; style?: React.CSSProperties }> = ({ size, glow = true, style }) => (
  <div style={{ width: size, height: size, borderRadius: size * 0.225, overflow: "hidden", background: theme.colors.black, border: `1px solid ${theme.colors.lineStrong}`, boxShadow: glow ? `0 0 ${size * 0.35}px ${theme.colors.glowSoft}, ${theme.shadow.card}` : theme.shadow.float, ...style }}>
    <Img src={staticFile("logo-google-ai-studio.jpg")} style={{ width: "100%", height: "100%", objectFit: "contain", display: "block" }} />
  </div>
);

/* ---------- mouse cursor with eased path + click ripple ---------- */
export const Cursor: React.FC<{ frames: number[]; xs: number[]; ys: number[]; clickAt?: number }> = ({ frames, xs, ys, clickAt }) => {
  const frame = useCurrentFrame();
  const o = { easing: theme.ease.inOut, ...clamp } as const;
  const x = interpolate(frame, frames, xs, o);
  const y = interpolate(frame, frames, ys, o);
  const vis = interpolate(frame, [frames[0], frames[0] + 6], [0, 1], clamp);
  const dip = clickAt === undefined ? 0 : interpolate(frame, [clickAt - 2, clickAt + 2, clickAt + 8], [0, 1, 0], clamp);
  const rip = clickAt === undefined ? 0 : interpolate(frame, [clickAt, clickAt + 16], [0, 1], { easing: theme.ease.out, ...clamp });
  return (
    <>
      {clickAt !== undefined && frame >= clickAt && rip < 1 && (
        <div style={{ position: "absolute", left: x - 40, top: y - 40, width: 80, height: 80, borderRadius: "50%", border: `3px solid ${theme.colors.primary}`, opacity: 1 - rip, transform: `scale(${0.3 + rip * 1.6})` }} />
      )}
      <div style={{ position: "absolute", left: x - 6, top: y - 4, opacity: vis, transform: `scale(${1 - dip * 0.14})`, transformOrigin: "6px 4px" }}>
        <CursorIcon />
      </div>
    </>
  );
};

/* ---------- browser / app window chrome ---------- */
export const WindowFrame: React.FC<{ width: number; height: number; title?: React.ReactNode; style?: React.CSSProperties; children?: React.ReactNode }> = ({ width, height, title, style, children }) => (
  <GlassCard style={{ width, height, borderRadius: theme.radius.lg, overflow: "hidden", ...style }}>
    <div style={{ height: 64, display: "flex", alignItems: "center", gap: 10, padding: "0 26px", borderBottom: `1px solid ${theme.colors.line}`, background: theme.colors.panel }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{ width: 14, height: 14, borderRadius: "50%", background: theme.colors.textFaint }} />
      ))}
      <div style={{ marginLeft: 22, flex: 1, display: "flex", alignItems: "center" }}>{title}</div>
    </div>
    <div style={{ position: "relative", width: "100%", height: height - 64 }}>{children}</div>
  </GlassCard>
);

/* ---------- process rail (File → AI Studio → Prompt → Send → Test), continuous across scenes 5-9 ---------- */
const RAIL_LABELS = ["File", "AI Studio", "Prompt", "Send", "Test"];
const railBounds = () => [
  cueFrame(11) - LEAD_FRAMES,
  cueFrame(14) - LEAD_FRAMES,
  cueFrame(16) - LEAD_FRAMES,
  cueFrame(22) - LEAD_FRAMES,
  cueFrame(24) - LEAD_FRAMES,
];
export const railWindow = () => {
  const b = railBounds();
  const end = scenes.find((s) => s.id === "test")!.to;
  return { start: b[0], end };
};

export const ProcessRail: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const b = railBounds();
  const { start, end } = railWindow();
  if (frame < start - 2 || frame > end) return null;
  const prog = b.slice(1).reduce((a, f) => a + Math.min(1, spring({ frame: frame - f, fps, config: theme.spring.smooth })), 0);
  const W = 1180;
  const exitAt = end - 12;
  return (
    <div style={{ position: "absolute", left: (1920 - W) / 2, bottom: 64, width: W, height: 96 }}>
      <Pop delay={start} y={50} exitAt={exitAt} style={{ width: W, height: 96, position: "relative" }}>
        <div style={{ position: "absolute", left: 20, right: 20, top: 20, height: 4, borderRadius: 4, background: theme.colors.line }} />
        <div style={{ position: "absolute", left: 20, top: 20, height: 4, borderRadius: 4, width: ((W - 40) * prog) / 4, background: `linear-gradient(90deg, ${theme.colors.primary}, ${theme.colors.accent})`, boxShadow: `0 0 18px ${theme.colors.glow}` }} />
        {RAIL_LABELS.map((label, i) => {
          const cx = 20 + ((W - 40) * i) / 4;
          const done = prog >= i + 0.92;
          const active = !done && prog > i - 0.5;
          return (
            <div key={label} style={{ position: "absolute", left: cx - 90, top: 0, width: 180, display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div style={{ width: 44, height: 44, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: done ? theme.colors.accent : active ? theme.colors.primary : theme.colors.surface2, border: `2px solid ${done ? theme.colors.accent : active ? theme.colors.primary : theme.colors.lineStrong}`, boxShadow: active ? `0 0 28px ${theme.colors.glow}` : undefined, transform: `scale(${active ? 1.12 : 1})` }}>
                {done ? <CheckIcon size={24} color={theme.colors.bg} sw={3} /> : <div style={{ width: 12, height: 12, borderRadius: "50%", background: active ? theme.colors.bg : theme.colors.textFaint }} />}
              </div>
              <div style={{ marginTop: 8, fontFamily: theme.fonts.display, fontSize: 26, fontWeight: active ? theme.fonts.weight.heavy : theme.fonts.weight.medium, lineHeight: theme.lh.body, letterSpacing: 0, color: active ? theme.colors.text : done ? theme.colors.textDim : theme.colors.textFaint }}>{label}</div>
            </div>
          );
        })}
      </Pop>
    </div>
  );
};

export { useSpringAt };
