import React from "react";
import { AbsoluteFill, interpolate, random, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "./theme";
import { clamp } from "./motion";
import { scenes } from "./timeline";
import { HEIGHT, WIDTH } from "./config";

/* Layer 1: persistent background mesh. Orbs glide to a new anchor at every scene change. */
type Anchor = [number, number, number, number, number, number];
const anchors: Anchor[] = [
  [1400, 300, 300, 900, 1000, 100], // hook
  [600, 400, 1500, 900, 300, 100], // broken
  [960, 540, 200, 200, 1700, 900], // relax
  [1500, 250, 400, 950, 900, 600], // chat
  [400, 300, 1500, 800, 1000, 1000], // data
  [1000, 200, 200, 900, 1700, 500], // studio
  [960, 600, 1700, 150, 150, 700], // guide
  [1500, 700, 300, 300, 960, 1000], // send
  [500, 250, 1500, 900, 960, 500], // test
  [960, 450, 300, 900, 1650, 200], // cta
];

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const prog = scenes.slice(1).reduce((acc, s) => acc + Math.min(1.02, spring({ frame: frame - s.from, fps, config: theme.spring.soft })), 0);
  const i = Math.max(0, Math.min(anchors.length - 2, Math.floor(prog)));
  const t = Math.max(0, Math.min(1, prog - i));
  const pos = anchors[i].map((v, k) => v + (anchors[i + 1][k] - v) * t);
  const sway = (k: number) => Math.sin(frame / (60 + k * 13)) * 40;
  const dotShift = (frame * 0.3) % 56;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1500, height: 1500, left: pos[0] - 750 + sway(0), top: pos[1] - 750, background: `radial-gradient(circle, ${theme.colors.primary}3a, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, left: pos[2] - 500 - sway(1), top: pos[3] - 500, background: `radial-gradient(circle, ${theme.colors.accent}20, transparent 64%)` }} />
      <div style={{ position: "absolute", width: 1100, height: 1100, left: pos[4] - 550 + sway(2), top: pos[5] - 550, background: `radial-gradient(circle, ${theme.colors.primary}26, transparent 66%)` }} />
      {/* dot grid with soft radial mask */}
      <AbsoluteFill style={{ WebkitMaskImage: "radial-gradient(ellipse at 50% 46%, black 15%, transparent 74%)", maskImage: "radial-gradient(ellipse at 50% 46%, black 15%, transparent 74%)" }}>
        <svg width={WIDTH} height={HEIGHT + 56} style={{ transform: `translateY(${-dotShift}px)` }}>
          <defs>
            <pattern id="dots" width="56" height="56" patternUnits="userSpaceOnUse">
              <circle cx="28" cy="28" r="1.5" fill="#fff" fillOpacity="0.16" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#dots)" />
        </svg>
      </AbsoluteFill>
      {/* drifting particles */}
      {Array.from({ length: 22 }).map((_, k) => {
        const x = random(`px${k}`) * WIDTH;
        const speed = 0.25 + random(`ps${k}`) * 0.5;
        const y = (HEIGHT + 60 - ((frame * speed + random(`py${k}`) * HEIGHT) % (HEIGHT + 120)));
        const r = 1.5 + random(`pr${k}`) * 2.5;
        const tw = 0.25 + 0.35 * Math.abs(Math.sin(frame / 30 + k));
        return <div key={k} style={{ position: "absolute", left: x + Math.sin(frame / 50 + k) * 18, top: y, width: r * 2, height: r * 2, borderRadius: "50%", background: k % 5 === 0 ? theme.colors.accent : theme.colors.primary, opacity: tw }} />;
      })}
    </AbsoluteFill>
  );
};

/* Layer 4: colour grade (unifies everything) */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.16 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.14), transparent 26%, transparent 70%, rgba(0,0,0,0.24))" }} />
  </AbsoluteFill>
);

/* Layer 5a: procedural film grain */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />
  );
};

/* Layer 5b: vignette (topmost) */
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 54%, rgba(0,0,0,0.5) 100%)" }} />
);

/* Scene transitions: a skewed glass panel sweeps across; the cut happens while it covers the frame. */
export const Transitions: React.FC = () => {
  const frame = useCurrentFrame();
  const HALF = 8;
  return (
    <>
      {scenes.slice(1).map((s, k) => {
        const B = s.from;
        if (frame < B - HALF || frame > B + HALF) return null;
        const dir = k % 3; // 0: left→right, 1: bottom→top, 2: right→left
        const p = interpolate(frame, [B - HALF, B + HALF], [0, 1], { easing: theme.ease.wipe, ...clamp });
        const vertical = dir === 1;
        const travel = interpolate(p, [0, 1], [-135, 135]) * (dir === 2 ? -1 : 1) * (vertical ? -1 : 1);
        const common: React.CSSProperties = vertical
          ? { left: 0, width: "100%", top: "-17.5%", height: "135%", transform: `translateY(${travel}%) skewY(-6deg)` }
          : { top: 0, height: "100%", left: "-17.5%", width: "135%", transform: `translateX(${travel}%) skewX(-12deg)` };
        const edge = vertical
          ? { left: 0, right: 0, top: dir === 1 ? 0 : undefined, height: 6 }
          : { top: 0, bottom: 0, [dir === 2 ? "left" : "right"]: 0, width: 6 };
        return (
          <div key={s.id} style={{ position: "absolute", ...common, background: `linear-gradient(${vertical ? 180 : 100}deg, ${theme.colors.surface2}, ${theme.colors.bgAlt})`, boxShadow: `0 0 80px ${theme.colors.glow}` }}>
            <div style={{ position: "absolute", ...(edge as React.CSSProperties), background: theme.colors.primary, boxShadow: `0 0 36px 6px ${theme.colors.glow}` }} />
          </div>
        );
      })}
    </>
  );
};
