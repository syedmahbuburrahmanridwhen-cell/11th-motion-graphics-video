// theme.ts — single source of truth: colours, fonts, easing, springs, shape language.
// Colour scheme: "Obsidian Blue" (user choice 1). Never inline hex/easing in components.
import { Easing } from "remotion";

export const theme = {
  colors: {
    bg: "#05070D",
    bgAlt: "#0A0F1C",
    surface: "#0E1424",
    surface2: "#141C31",
    primary: "#4C8DF6", // hero
    accent: "#34D399",
    text: "#F4F7FF",
    textDim: "#8E9AB8",
    textFaint: "#4A5675",
    line: "rgba(255,255,255,0.09)",
    lineStrong: "rgba(255,255,255,0.16)",
    glow: "rgba(76,141,246,0.45)",
    glowSoft: "rgba(76,141,246,0.18)",
    accentGlow: "rgba(52,211,153,0.35)",
    primaryTint: "rgba(76,141,246,0.16)",
    primaryLine: "rgba(76,141,246,0.5)",
    accentTint: "rgba(52,211,153,0.12)",
    accentLine: "rgba(52,211,153,0.4)",
    panel: "rgba(255,255,255,0.03)",
    black: "#000000",
  },
  fonts: {
    // Bundled in public/fonts (works fully offline) — see src/fonts.ts
    display: "'Hind Siliguri', 'Noto Sans Bengali', system-ui, sans-serif",
    body: "'Hind Siliguri', 'Noto Sans Bengali', system-ui, sans-serif",
    weight: { heavy: 700, medium: 500 },
  },
  // Bengali needs generous line-height so matras/ref never clip.
  lh: { hero: 1.28, body: 1.4 },
  radius: { sm: 14, md: 24, lg: 36, pill: 999 },
  shadow: {
    card: "0 40px 90px -30px rgba(0,0,0,0.75), 0 0 0 1px rgba(255,255,255,0.07)",
    float: "0 24px 60px -24px rgba(0,0,0,0.8)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
    wipe: Easing.bezier(0.65, 0, 0.35, 1), // scene-transition panels
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
    soft: { damping: 26, stiffness: 70, mass: 1 },
  },
  // Entrance / exit durations in seconds (converted with fps in code)
  dur: { enter: 0.7, exit: 0.3 },
} as const;

export type Theme = typeof theme;
